# Credits

- **Mishka Midsummer** — mod concept, direction and presentation.
- **OpenAI Codex** — programming and technical analysis assistance.
- **LazyDuchess** — Sims2RPC, [TS2 Extender](https://github.com/LazyDuchess/TS2-Extender) source and published technical references.
- **ThirteenAG** — [Ultimate ASI Loader](https://github.com/ThirteenAG/Ultimate-ASI-Loader).
- **Maxis / Electronic Arts** — The Sims 2, original plumbob and game font adaptation.
- **ITC / Adobe** — original typeface.
- **oduska** — [HomeCrafter Plus Portable](https://modthesims.info/d/699956/the-sims-2-homecrafter-plus-portable-version.html), the distribution used for the original game font.
- **i like cheesey oranges** — [Plumbob Cursor](https://modthesims.info/d/249765/requested-by-msw-plumbob-cursor.html), the source of the plumbob frame; artwork credited to EA.

See [asset provenance](assets/PROVENANCE.md) for resource details and original notices.
