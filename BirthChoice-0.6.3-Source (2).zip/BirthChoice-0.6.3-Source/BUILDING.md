# Building BirthChoice

Use Linux or WSL with Bash, Python 3, pip and venv. The build targets **32-bit Windows** (`x86-windows-gnu`).

## Compile

Run from the source directory:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements-build.txt
bash build.sh
```

The compiler is pinned to **ziglang==0.13.0**. Keep the virtual environment activated: `build.sh` invokes `python`.

Output: `MishkaMidsummer_BabyGenderChoice.asi`.

The generated `src/ui_assets.c` is included. Compilation does not require a game installation.

## Verify

Build the ASI first, then run:

```bash
python -m pip install -r requirements-tests.txt
python tests/verify_binary.py /path/to/UC.exe
python tests/verify_legacy_port.py /path/to/UC.exe /path/to/EA-Legacy.exe /path/to/EA-Legacy.bcdiag
python tests/verify_steam_port.py /path/to/UC.exe /path/to/Steam-Legacy.exe /path/to/Steam-Legacy.bcdiag
```

Use your own matching executables and diagnostic captures. Expected hashes and capture layouts are recorded in [the validation logs](docs/TESTING_STATUS.md) and [Steam port notes](docs/STEAM_PORT.md). The EA and Steam scripts also run the UC checks.

The tests use `pefile`, `capstone` and `unicorn`; their versions are not pinned. Windows APIs, UI responses and unrelated engine methods are test doubles. These checks do not replace gameplay testing. Game executables and captures are not included.

## Regenerate assets (optional)

- `python tools/embed_ui_assets.py` regenerates embedded assets from `assets/` and requires Pillow.
- `tools/convert_game_font.py` requires fontTools and an original MXF input. See `--help` and [asset provenance](assets/PROVENANCE.md).

Neither step is required for a normal build.
