# Testing status

| Target | Evidence |
|---|---|
| Steam Legacy 1.18.0.187, BirthChoice 0.6.3 | Successful gameplay reported on **4 October 2026**. |
| EA Legacy 1.18.0.189, BirthChoice 0.6.1 | Successful gameplay reported on **4 October 2026**. |
| EA/UC and Steam, BirthChoice 0.6.3 | Passing emulator checks in the validation logs below. |

Gameplay reports do not establish separate coverage of every birth or adoption route, multiple birth, save/reload, age-up or third-party mod combination. The EA gameplay report concerns 0.6.1.

The emulator checks use test doubles for Windows APIs, UI responses and unrelated game methods. Their logs document those runs:

- [EA/UC validation](VALIDATION_EA_UC_0.6.3.txt)
- [Steam validation](VALIDATION_STEAM_0.6.3.txt)

Released ASI SHA-256:

```text
69df85e71257c6b660c7181c2871196a33750d3cd2826f51939e59732828133d
```
