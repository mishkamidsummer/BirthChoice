# Steam Legacy 1.18.0.187 port

The Steam profile is based on a capture from the running game. Successful
gameplay was reported on 4 October 2026. See [testing status](TESTING_STATUS.md).

## Inputs

- EXE SHA-256: `24041f834e979cc088714713c3207540ff9093f51ff126450a4f7989432156b6`
- Capture SHA-256: `75fbbf58890a5cd524f974e3093e70ffc6971a5e5bd670fd53b42769883b143a`
- PE timestamp: `67F41BFE`; image size: `0120F000`.
- Captured runtime base: `9FD80000`.
- .text RVA/size: `00001000` / `00D9877E`.
- .rdata RVA/size: `00D9A000` / `0025099E`.

The strict BCST0001 parser validates the complete capture. The image was read
after normal Steam startup; activation and protected disk code are unchanged.
Only the captured .text and .rdata bytes are used for analysis.
The capture and game executable are not included in the source archive.

## Verified RVAs

| Item | EA Legacy 1.18.0.189 | Steam Legacy 1.18.0.187 |
|---|---|---|
| Genetic processor | 507840 | 507600 |
| Genetic phase dispatcher | 50787C | 50763C |
| Genetic phase 1 | 5079AE | 50776E |
| Genetic hook / resume | 507AC2 / 507AC7 | 507882 / 507887 |
| Genetic original RNG call target | 1B8F48 | 1B8C78 |
| General processor | 5085F0 | 5083B0 |
| General phase dispatcher | 508664 | 508424 |
| General phase 1 | 508755 | 508515 |
| General hook / resume | 5087F5 / 5087FB | 5085B5 / 5085BB |
| Language cache accessor | 20E0F6 | 20DE26 |
| Language cache | 12E5BF4 | 10CC2DC |
| Language interface vtable | 10761F8 | E9F0A0 |
| Language vtable+1Ch getter | 147A40 | 147770 |
| Language field | +2Ch | +2Ch |

The genetic hook sees EDI as the creation state and EBP-20h as the resolved
gender. Its displaced five bytes are `mov ecx,[edi+14h]; push 1`.
The general hook sees ESI as the creation state and state+0Ch as the resolved
gender. Its displaced six bytes are `mov ecx,[esi+24h]; push [esi+08h]`.
Both layouts match the existing Legacy stubs. Species/age filters and phase
progression were checked against the captured code, rather than inferred from
an address delta alone.

Original random and special-case gender selection runs first. The selected
value then reaches both the original person-data 41h assignment and appearance
builder +CCh setter. No new baby is rerolled, and the number of babies is not
changed. Existing babies and non-baby general creation do not trigger a choice.
Coverage of individual generator packages still depends on their creation route.

## Language mapping evidence

The accessor at 20DE26 acquires the interface using IDs `0054B7D5` and
`441E5070` at 20DB44, matching the EA language service. The E9F0A0 vtable's
QueryInterface target C747AC recognizes `0054B7D5`. The constructor assigns
E9F0A0 and initializes field +2Ch to 1. Vtable+1Ch points to 147770, whose
instructions are `mov eax,[ecx+2Ch]; ret`.
The mod verifies the interface vtable before reading its language field.
German IDs 4/39 use German strings; other/missing values use English.
The UI uses the game language, independently of the Windows display language.

## Installation guards

The new profile matches PE32/x86, timestamp and image size, then verifies
twelve instruction ranges and six relocated addresses before either hook is
written. Unknown or altered builds are rejected. The entry point is not used
as an activation-dependent profile key. Plugin pinning, both writable-memory
checks and rel32 arithmetic are unchanged from 0.6.2.
The Steam test session banner is `BirthChoice 0.6.3-steam-test: ASI loaded`;
existing diagnostic line prefixes remain BC06.

## Verification scope

`verify_steam_port.py` loads the actual compiled ASI and the captured game
instructions into an x86 emulator. It executes both phase dispatches, gender
result handling, person-data and appearance setter calls, and the next-phase
transition. Windows services, UI response, RNG return values and unrelated
virtual methods are test doubles. The mod is installed through its actual
production installer rather than manually wiring the hooks.

Checks cover captured base 9FD80000 and synthetic base 04000000, each with
plugin bases 10000000/30000000; both natural genders; Keep/change/dialog
failure; stack/register/flags/x87/SIMD preservation; German/English/fallback
language; fixed/random gender and random baby age; same-parent cases;
pets/non-babies/invalid selectors; 70 independent choices; every instruction
and relocated-address guard; unknown build; pin/protection failures; and
rejection of a second installation without partial writes.

The synthetic low-base fixture relocates only the decoded absolute operands
and jump tables needed by these scoped tests. It is not a reconstruction of
a runnable game executable and does not test Steam's loader or activation.

The EA/UC regression checks also passed against this ASI. The emulator does
not test Steam loading, dialog focus, complete birth/adoption delivery,
saving/reloading, age-up or third-party crib behavior. The gameplay report
does not establish individual coverage of all these cases. Compatibility
is limited to the captured Steam build.
