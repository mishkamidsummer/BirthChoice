# Code map

| Path | Role |
|---|---|
| `src/birth_choice.c` | Plugin setup, guards, hook installation and baby-choice handling |
| `src/build_profiles.h` | Build-specific addresses and instruction/address guards |
| `src/hooks.S` | x86 assembly hook stubs |
| `src/dialog_ui.c`, `.h` | Windows dialog and controls |
| `src/dialog_theme.c`, `.h` | Shared dialog drawing and theme |
| `src/strings.h` | Interface strings |
| `src/ui_assets.c`, `.h` | Generated embedded font and bitmap data |
| `src/exports.def` | DLL export definitions |
| `build.sh` | Zig-based Windows x86 compilation |
| `tests/` | Binary and emulator checks using matching game inputs |
| `tools/` | Asset conversion, embedding and diagnostic-capture readers |
| `assets/PROVENANCE.md` | Asset sources and notices |

Start with `birth_choice.c`, `build_profiles.h` and `hooks.S` for game integration, or `dialog_ui.c` for UI behavior.
