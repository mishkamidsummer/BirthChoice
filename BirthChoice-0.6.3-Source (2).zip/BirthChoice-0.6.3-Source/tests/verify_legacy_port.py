"""Verify the compiled 0.6 plugin against a real Legacy runtime code capture.
Runs the existing UC regression suite first, then Legacy installation and hooks.
Windows APIs, UI and unrelated virtual engine methods are test doubles.
No live game or save-file testing is performed.
Usage: python tests/verify_legacy_port.py UC.exe LEGACY.exe LEGACY.bcdiag
"""
from pathlib import Path
import sys,struct,runpy,hashlib
import pefile
from capstone import Cs,CS_ARCH_X86,CS_MODE_32
from unicorn import UC_HOOK_CODE
from unicorn.x86_const import *
ROOT=Path(__file__).resolve().parents[1]
if len(sys.argv)!=4:raise SystemExit(__doc__)
uc_path,lc_path,capture_path=sys.argv[1:]
sys.path.insert(0,str(ROOT/'tools'))
from read_legacy_capture import load_capture
capture=load_capture(Path(capture_path).read_bytes())
original=pefile.PE(lc_path)
assert original.FILE_HEADER.TimeDateStamp==capture['timestamp']
assert original.OPTIONAL_HEADER.SizeOfImage==capture['image_size']
sys.argv=[str(ROOT/'tests/verify_binary.py'),uc_path]
uc=runpy.run_path(sys.argv[0])
Machine=uc['Machine'];S=uc['S'];D=uc['D'];STUB=uc['STUB'];pack=uc['pack']
FRAME=S+0x1000

# EA activation handles the protected code's relocations separately from the
# on-disk PE relocation directory. For the alternate-base fixture, relocate
# decoded absolute operands in the profiled functions and their jump tables.
# This tests our relative addressing, not EA's activation/relocation machinery.
# No protected on-disk text is substituted for the captured instructions.
def runtime_image(base):
 image=bytearray(capture['image_size'])
 image[:4096]=Path(lc_path).read_bytes()[:4096]
 for section in capture['sections']:
  r=section['rva'];image[r:r+len(section['data'])]=section['data']
 delta=(base-capture['base'])&0xffffffff
 if delta:
  relocations=set()
  decoder=Cs(CS_ARCH_X86,CS_MODE_32);decoder.detail=True
  for start,end in [(0x507840,0x5085b0),(0x5085f0,0x508e14),
                    (0x2675e0,0x267608),(0x54b900,0x54b928),(0x20e0f6,0x20e121)]:
   for instruction in decoder.disasm(bytes(image[start:end]),capture['base']+start):
    for offset,size in [(instruction.disp_offset,instruction.disp_size),
                        (instruction.imm_offset,instruction.imm_size)]:
     if size!=4:continue
     rva=instruction.address-capture['base']+offset
     value=struct.unpack_from('<I',image,rva)[0]
     if capture['base']<=value<capture['base']+capture['image_size']:relocations.add(rva)
  for start,count in [(0x5085b0,7),(0x508e14,8),(0x508e34,7),(0x267608,4),(0x54b928,8),(0x1076214,1)]:
   relocations.update(start+4*i for i in range(count))
  for rva in relocations:
   value=struct.unpack_from('<I',image,rva)[0]
   assert capture['base']<=value<capture['base']+capture['image_size'],hex(rva)
   struct.pack_into('<I',image,rva,(value+delta)&0xffffffff)
 return bytes(image)

IMAGES={base:runtime_image(base) for base in [capture['base'],0x04000000]}
PRESERVED=[UC_X86_REG_EAX,UC_X86_REG_EBX,UC_X86_REG_EDX,UC_X86_REG_ESI,
 UC_X86_REG_EDI,UC_X86_REG_EBP,UC_X86_REG_EFLAGS,UC_X86_REG_FPCW,
 UC_X86_REG_FPSW,UC_X86_REG_FPTAG,UC_X86_REG_MXCSR]+[UC_X86_REG_XMM0+i for i in range(8)]

class Legacy(Machine):
 def __init__(self,base=capture['base'],dll_base=0x10000000,language=1,corrupt=None,protect_fail=0,pin_fail=False):
  self.base=base;self.protect_fail=protect_fail;self.pin_fail=pin_fail;self.protections=[];self.flushed=[];self.logs=[]
  self.hook_snapshot=None;self.checked_hooks=0;self.parent_missing=False;self.parent_two_missing=False
  self.parent_occult=(0,0);self.parent_sex=0
  super().__init__(dll_base=dll_base,language=language)
  self.u.mem_map(base,(capture['image_size']+4095)&~4095)
  self.u.mem_write(base,IMAGES[base])
  self.w(base+0x12e5bf4,D+0xd00 if language is not None else 0)
  self.w(D+0xd00,base+0x10761f8 if language!='unknown_manager' else 0)
  self.w(D+0xd2c,language if isinstance(language,int) else 1)
  self.w(D+0xd30,4 if language==1 else 1) # old offset must never select the language
  # These three external calls are replaced by the same unrelated method doubles
  # used for UC. The actual phase dispatch, gender math and setters stay intact.
  self.u.mem_write(base+0x1b8f48,b'\xdd\x05'+pack(D+0xb00)+b'\xc3')
  self.extra={base+0x1ae45d:'factory_service',STUB+0x4000:'neighbours',STUB+0x4010:'lookup'}
  self.w(D+0x1400,D+0x1450);self.w(D+0x1450+0x28,STUB+0x4000)
  self.w(D+0x1500,D+0x1550);self.w(D+0x1550+0x40,STUB+0x4010)
  for ptr in [D+0x1700,D+0x1800]:self.w(ptr,D+0x600)
  if corrupt:
   address,data=corrupt
   self.u.mem_write(base+address,data)
  self.before=[bytes(self.u.mem_read(base+r,n)) for r,n in [(0x507ac2,5),(0x5087f5,6)]]
  self.installed=self.call_install()
  if self.installed:
   for rva,symbol,n in [(0x507ac2,'legacy_gender_stub',5),(0x5087f5,'legacy_generated_stub',6)]:
    assert bytes(self.u.mem_read(base+rva,5))==b'\xe9'+pack(self.ex[symbol]-(base+rva+5))
    if n==6:assert bytes(self.u.mem_read(base+rva+5,1))==b'\x90'
   assert self.r(self.ex['gender_resume'])==base+0x507ac7
   assert self.r(self.ex['generated_resume'])==base+0x5087fb
   assert self.flushed==[(base+0x507ac2,5),(base+0x5087f5,6)]
  else:
   assert self.before==[bytes(self.u.mem_read(base+r,n)) for r,n in [(0x507ac2,5),(0x5087f5,6)]]
   assert not self.flushed
   if not (corrupt or protect_fail or pin_fail):raise AssertionError((hex(base),self.logs,[(hex(r),hex(self.r(base+r))) for r in [0x5085b4,0x508e18,0x20e0fb,0x20e111,0x20e11b,0x1076214]]))
 def call_install(self):
  self.w(S,STUB+0xff00);self.u.reg_write(UC_X86_REG_ESP,S)
  self.u.emu_start(self.ex['install_hooks'],STUB+0xff00,count=200000)
  assert self.reg(UC_X86_REG_EIP)==STUB+0xff00
  assert self.reg(UC_X86_REG_ESP)==S+4
  return self.reg(UC_X86_REG_EAX)
 def hook(self,u,a,size,data):
  if a in self.imports:
   name=self.imports[a]
   if name=='GetTempPathW':
    _,dest=self.args(2);u.mem_write(dest,'C:\\Temp\\\0'.encode('utf-16-le'));return self.ret(8,8)
   if name=='lstrcatW':
    dest,src=self.args(2)
    def wide(ptr):
     out=b''
     while (pair:=bytes(u.mem_read(ptr+len(out),2)))!=b'\0\0':out+=pair
     return out
    u.mem_write(dest,wide(dest)+wide(src)+b'\0\0');return self.ret(dest,8)
   if name=='CreateFileW':return self.ret(1,28)
   if name=='WriteFile':
    _,buf,n,out,_=self.args(5);self.logs.append(bytes(u.mem_read(buf,n)).decode());self.w(out,n);return self.ret(1,20)
   if name=='CloseHandle':return self.ret(1,4)
   if name=='strlen':
    ptr=self.args(1)[0];n=0
    while bytes(u.mem_read(ptr+n,1))!=b'\0':n+=1
    return self.ret(n)
   if name=='GetModuleHandleW':return self.ret(self.base,4)
   if name=='GetModuleHandleExW':return self.ret(not self.pin_fail,12)
   if name=='GetCurrentProcess':return self.ret(0xffffffff)
   if name=='VirtualProtect':
    address,n,protection,out=self.args(4);self.protections.append((address,n,protection))
    if self.protect_fail==len(self.protections):return self.ret(0,16)
    self.w(out,0x20);return self.ret(1,16)
   if name=='FlushInstructionCache':
    _,address,n=self.args(3);self.flushed.append((address,n));return self.ret(1,12)
  if a in [self.base+0x507ac2,self.base+0x5087f5]:
   general=a==self.base+0x5087f5
   self.dialog_natural=self.r(D+12 if general else FRAME-0x20)
   self.hook_snapshot={r:self.reg(r) for r in PRESERVED}
   self.hook_stack=self.reg(UC_X86_REG_ESP)
  if a in [self.base+0x507ac7,self.base+0x5087fb] and self.hook_snapshot:
   general=a==self.base+0x5087fb
   for r,v in self.hook_snapshot.items():assert self.reg(r)==v,('register not preserved',r,hex(a))
   assert self.reg(UC_X86_REG_ESP)==self.hook_stack-4
   assert self.r(self.hook_stack-4)==(self.r(D+8) if general else 1)
   assert self.reg(UC_X86_REG_ECX)==(D+0x900 if general else D+0x500)
   self.checked_hooks+=1;self.hook_snapshot=None
  if a==self.base+0x1b8f48:self.rng_calls+=1;return
  if a==STUB+0x20:
   pd=self.args(1)[0]
   if pd==0x41:return self.ret(self.parent_sex,4)
   assert pd==0xa5
   return self.ret(self.parent_occult[0 if self.reg(UC_X86_REG_ECX)==D+0x1700 else 1],4)
  if a in self.extra:
   name=self.extra[a]
   if name=='factory_service':return self.ret(D+0x700)
   if name=='neighbours':return self.ret(D+0x1500)
   if name=='lookup':
    nid,mode=self.args(2);assert mode==1
    return self.ret(0 if (self.parent_missing or (self.parent_two_missing and nid==2)) else D+(0x1700 if nid==1 else 0x1800),8)
  return super().hook(u,a,size,data)
 def setup_registers(self):
  for r,v in {UC_X86_REG_ESP:S,UC_X86_REG_EBP:FRAME,UC_X86_REG_EBX:0x77778888,
              UC_X86_REG_EFLAGS:0x202}.items():self.u.reg_write(r,v)
  for i in range(8):self.u.reg_write(UC_X86_REG_XMM0+i,0x123456789abcdef+i)
  self.u.reg_write(UC_X86_REG_MXCSR,0x3f80);self.u.reg_write(UC_X86_REG_FPCW,0x27f)
  self.writes=[]
 def genetic(self,choice=None,natural=1,p2=2,species=1,nid=80):
  assert self.installed
  if choice is not None:self.choices.append(choice)
  self.nid=nid
  for i,v in enumerate([1,1,p2,species,0,D+0x500,0,0]):self.w(D+4*i,v)
  self.w(FRAME+8,D);self.w(FRAME-0x34,D+0xc00)
  self.u.mem_write(D+0xb00,struct.pack('<d',.25 if natural==1 else .75))
  self.setup_registers()
  self.u.reg_write(UC_X86_REG_EDI,D);self.u.reg_write(UC_X86_REG_ESI,D+0x1400)
  self.u.emu_start(self.base+0x50787c,self.base+0x507b74,count=200000)
  assert self.reg(UC_X86_REG_EIP)==self.base+0x507b74
  assert self.reg(UC_X86_REG_ESP)==S and self.reg(UC_X86_REG_EBP)==FRAME
  assert self.r(D)==2 and not self.choices
  selected=self.r(FRAME-0x20)
  assert ('sex',selected) in self.writes
  assert ('person',0x41,1 if selected==1 else 0) in self.writes
  assert ('person',0x3a,1) in self.writes and ('age',0x20) in self.writes
  before=len(self.dialogs);self.u.reg_write(UC_X86_REG_EDI,D)
  self.u.emu_start(self.base+0x50787c,self.base+0x507bff,count=1000)
  assert self.reg(UC_X86_REG_EIP)==self.base+0x507bff and len(self.dialogs)==before
  return selected
 def generated(self,choice=None,age=0x20,species=0,gender=-1,random_sex=1,random_age=0x20):
  assert self.installed
  if choice is not None:self.choices.append(choice)
  self.random_age=random_age;self.random_sex=random_sex
  for i,v in enumerate([1,species,age,gender,0,0,0,D+0x500,0,D+0x900,0]):self.w(D+4*i,v)
  self.w(FRAME-0x1c,D+0x1100)
  self.setup_registers();self.u.reg_write(UC_X86_REG_ESI,D)
  self.u.emu_start(self.base+0x508664,self.base+0x508887,count=200000)
  assert self.reg(UC_X86_REG_EIP)==self.base+0x508887
  assert self.reg(UC_X86_REG_ESP)==S and self.reg(UC_X86_REG_EBP)==FRAME
  assert self.r(D)==2 and not self.choices
  selected=self.r(D+12)
  assert ('sex',selected) in self.writes
  assert ('person',0x41,1 if selected==1 else 0) in self.writes
  assert ('age',self.r(D+8)) in self.writes
  if self.r(D+8)==0x20:assert ('person',0x3a,1) in self.writes
  before=len(self.dialogs)
  self.u.emu_start(self.base+0x508664,self.base+0x5088de,count=1000)
  assert self.reg(UC_X86_REG_EIP)==self.base+0x5088de and len(self.dialogs)==before
  return selected

# Correct build, ASLR and plugin relocation; test installation, not hand-wired hooks.
for base in IMAGES:
 for dll_base in [0x10000000,0x30000000]:
  for natural in [1,2]:
   for choice in [0,3-natural,-1]:
    m=Legacy(base,dll_base);assert m.genetic(choice,natural)==(choice if choice in [1,2] else natural)
    assert len(m.dialogs)==1 and m.rng_calls==1 and m.checked_hooks==1
    m=Legacy(base,dll_base);assert m.generated(choice,random_sex=natural)==(choice if choice in [1,2] else natural)
    assert len(m.dialogs)==1 and m.resolver_calls==1 and m.checked_hooks==1
print('PASS LC: actual high ASLR base and rebased low image, relocated plugin, real phase dispatch/RNG-result math/setters, Keep/change/error, both genders, register/flags/x87/SIMD preservation and no repeated next-phase popup')
for language in [1,4,39,3,6,0,999,None,'unknown_manager']:
 for natural in [1,2]:
  m=Legacy(language=language);assert m.genetic(3-natural,natural)==3-natural
  m=Legacy(language=language);assert m.generated(3-natural,random_sex=natural)==3-natural
print('PASS LC: verified language cache/vtable/field +2Ch; German-only strings, English fallback, both original gender messages, opposite buttons, multiple-birth hint and author credit')
for natural in [1,2]:
 for choice in [0,3-natural,-1]:
  m=Legacy();assert m.generated(choice,gender=natural)==(choice if choice in [1,2] else natural) and m.resolver_calls==0
m=Legacy();assert m.generated(2,age=-1)==2 and m.resolver_calls==2
for parent_sex in [0,1]:
 for choice in [0,1 if parent_sex else 2]:
  m=Legacy();m.parent_sex=parent_sex
  assert m.genetic(choice,p2=1)==(choice or (2 if parent_sex else 1))
print('PASS LC: fixed/random gender, random age resolved to baby, and same-parent special case retain the actual engine result before selection')
for age in [1,2,4,8,0x10,0x40]:
 m=Legacy();assert m.generated(age=age)==1 and not m.dialogs
for species in [1,2,3]:
 m=Legacy();assert m.generated(species=species)==1 and not m.dialogs
for species in [2,4,8]:
 m=Legacy();assert m.genetic(species=species)==1 and not m.dialogs
for general in [False,True]:
 for phase in [0,1,3,4,0xffffffff]:Legacy().selector_guard(general,phase=phase,neighbour=D+0x500)
 for natural in [0,3,0xffffffff]:Legacy().selector_guard(general,natural=natural,neighbour=D+0x500)
 for nid in [0,0xffff]:Legacy().selector_guard(general,nid=nid,neighbour=D+0x500)
 Legacy().selector_guard(general,neighbour=0)
print('PASS LC: non-baby ages, pets, invalid phases/genders/NIDs and missing neighbours do not open a dialog')
m=Legacy();m.dialog_delay=600000
for i in range(70):assert m.genetic(2 if i%2 else 0,nid=80+i)==(2 if i%2 else 1)
assert len(m.dialogs)==70
print('PASS LC: 70 independent new-baby choices, without a time limit or pending queue')

# Exercise every runtime guard with an independent corruption.
import re
profile=(ROOT/'src/build_profiles.h').read_text().split('static const Guard lc_guards[]={')[1].split('};')[0]
guard_rvas=[int(x,16) for x in re.findall(r'\{0x([0-9a-f]+),',profile)]
address_rvas=[0x5085b4,0x508e18,0x20e0fb,0x20e111,0x20e11b,0x1076214]
for rva in guard_rvas+address_rvas:
 bad=bytes([IMAGES[capture['base']][rva]^1]);assert not Legacy(corrupt=(rva,bad)).installed
stamp_rva=original.DOS_HEADER.e_lfanew+8
assert not Legacy(corrupt=(stamp_rva,pack(0))).installed
assert not Legacy(pin_fail=True).installed
for fail in [1,2]:
 m=Legacy(protect_fail=fail);assert not m.installed
 if fail==2:assert len(m.protections)==3 and m.protections[-1]==(m.base+0x507ac2,5,0x20)
m=Legacy();before=[bytes(m.u.mem_read(m.base+r,n)) for r,n in [(0x507ac2,5),(0x5087f5,6)]]
assert not m.call_install()
assert before==[bytes(m.u.mem_read(m.base+r,n)) for r,n in [(0x507ac2,5),(0x5087f5,6)]]
print('PASS LC: every instruction/address guard, unknown build, DLL pin failure, either protection failure, and a second installation are rejected without partial hook writes')
# The refactored installer must still recognise and patch the supported UC EXE.
m=Legacy.__new__(Legacy)
m.base=0x400000;m.protect_fail=0;m.pin_fail=False;m.protections=[];m.flushed=[];m.logs=[]
m.extra={};m.hook_snapshot=None
Machine.__init__(m)
m.u.mem_map(0x400000,0x1000);m.u.mem_write(0x400000,Path(uc_path).read_bytes()[:4096])
for rva,n in [(0x3e8dea,5),(0x3e43a1,6)]:m.u.mem_write(0x400000+rva,uc['game'].get_data(rva,n))
assert m.call_install()==1 and any('UC/EP9' in s for s in m.logs)
assert m.r(m.ex['gender_resume'])==0x7e8def and m.r(m.ex['generated_resume'])==0x7e43a7
assert m.sex(choice=2)==2 and m.general(choice=2)==2
print('PASS UC: actual production installer selects UC, installs both original stubs, and both creation paths still work')
print('Capture SHA256:',hashlib.sha256(Path(capture_path).read_bytes()).hexdigest())
print('ASI SHA256:',hashlib.sha256((ROOT/'MishkaMidsummer_BabyGenderChoice.asi').read_bytes()).hexdigest())
print('LIMIT: code emulation only. No live Windows/Legacy, birth animation, adoption delivery, saved character or Monique crib interaction was run.')
