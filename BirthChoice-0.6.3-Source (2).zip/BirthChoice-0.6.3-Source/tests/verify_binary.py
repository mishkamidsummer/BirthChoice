"""Exercise the built x86 ASI and real game instruction blocks in Unicorn.
Windows UI/services and unrelated engine virtual methods are test doubles.
This is NOT an in-game test. No supplied executable is changed on disk.
Usage: python tests/verify_binary.py PATH_TO_Sims2EP9RPC.exe [PATH_TO_Sims2EP9.exe]
Dependencies: pefile, unicorn, capstone.
"""
import sys, struct, hashlib, pathlib, argparse
import pefile
from unicorn import Uc, UC_ARCH_X86, UC_MODE_32, UC_HOOK_CODE
from unicorn.x86_const import *

ROOT=pathlib.Path(__file__).resolve().parents[1]
DLL=ROOT/'MishkaMidsummer_BabyGenderChoice.asi'
parser=argparse.ArgumentParser()
parser.add_argument('game',nargs='+')
options=parser.parse_args()
GAME=pathlib.Path(options.game[0])
game=pefile.PE(str(GAME))
expected={
 0x7e43a1:bytes.fromhex('8b4e248b56088b0152ff90c80000008b4e248b560c8b0152ff90cc000000'),
 0x7e443d:bytes.fromhex('8b460c488b4e1c740b8b116a006a41ff5244eb098b016a016a41ff5044'),
 0x7e8cec:bytes.fromhex('c70602000000'),
 0x7e4307:bytes.fromhex('c70602000000'),
 0x7e8dea:bytes.fromhex('8b4e148b116a016a3aff5244'),
 0x7e8d99:bytes.fromhex('8b4c241481c188000000e890f2c2ff'),
 0x7e8e18:bytes.fromhex('837c2418018b4e14750b8b116a016a41ff5244'),
 0x7e8e8b:bytes.fromhex('8b0f8b4424188b1150ff92cc000000'),
}
for path in options.game:
 p=pefile.PE(path)
 assert p.FILE_HEADER.Machine==0x14c
 assert p.FILE_HEADER.TimeDateStamp==0x48f12b6f
 assert p.OPTIONAL_HEADER.SizeOfImage==0x2c114e0
 assert p.OPTIONAL_HEADER.AddressOfEntryPoint==0xa5c0da
 for va,b in expected.items():assert p.get_data(va-0x400000,len(b))==b,(path,hex(va))
 # Active language manager cache and its native language field/getter.
 assert p.get_data(0xec1f47-0x400000,7)==bytes.fromhex('a10cc44a01c9c3')
 assert p.get_data(0x730323-0x400000,4)==bytes.fromhex('8b4130c3')
 assert p.get_data(0x12e208c-0x400000,4)==bytes.fromhex('23037300')
 assert p.get_data(0x10c27e1-0x400000,4)==bytes.fromhex('44270c01')
 assert p.get_data(0x10c2744-0x400000,5)==bytes.fromhex('6858112e01')
 assert p.get_data(0x12e1158-0x400000,8)==b'Deutsch\0'
 print('PASS: supplied executable guards',pathlib.Path(path).name)

pack=lambda n:struct.pack('<I',n&0xffffffff)
S=0x20008000
D=0x21000000
STUB=0x22000000

def game_operand_object():
 """Use the actual primitive-13 constructor and runtime copy method.
 Do not fake a serialized BHAV header: that was the defect in version 0.1.
 """
 u=Uc(UC_ARCH_X86,UC_MODE_32)
 for va,size in [(0x885000,0x3000),(0xee1000,0x2000),
                 (0x20000000,0x10000),(D,0x4000),(STUB,0x1000)]:
  u.mem_map(va,size)
  if va<0x20000000:u.mem_write(va,game.get_data(va-0x400000,size))
 # Verify primitive 13's actual factory case calls the constructor we execute.
 index=game.get_data(0x887128+0x13-0x400000,1)[0]
 case=struct.unpack('<I',game.get_data(0x887034+index*4-0x400000,4))[0]
 assert case==0x886635
 assert game.get_data(0x886655-0x400000,5)==bytes.fromhex('e846f3ffff')
 u.mem_write(S,pack(STUB));u.reg_write(UC_X86_REG_ESP,S)
 u.reg_write(UC_X86_REG_ECX,D+0x300)
 u.emu_start(0x8859a0,STUB,count=1000)
 header=bytes(u.mem_read(D+0x300,4))
 assert header==pack(0x1223618)
 # Actual SetOperands copies +4..+19 and the version byte at +20, preserving vtable.
 source=bytes(4)+bytes.fromhex('00000019000001000007000000000000')+bytes([0])
 u.mem_write(D+0x400,source)
 u.mem_write(D+0x10c,pack(D+0x300))
 u.mem_write(S,pack(STUB)+pack(D+0x400))
 u.reg_write(UC_X86_REG_ESP,S);u.reg_write(UC_X86_REG_ECX,D+0x100)
 u.emu_start(0x886260,STUB,count=1000)
 result=bytes(u.mem_read(D+0x300,21))
 assert result[:4]==header and result[4:]==source[4:]
 print('PASS: runtime operand fixture constructed by the real game code; first DWORD is vtable 01223618, not opcode 0013')
 return result

NODE=game_operand_object()

class Machine:
 def __init__(self,dll_base=0x10000000,dll_file=DLL,language=1):
  self.u=Uc(UC_ARCH_X86,UC_MODE_32)
  self.u.mem_map(0x20000000,0x10000)
  self.u.mem_map(D,0x4000)
  self.u.mem_map(STUB,0x10000)
  self.u.mem_map(0x14ac000,0x1000)
  for va,size in [(0x7e8000,0x2000),(0x7e4000,0x1000),(0xcd4000,0x1000),(0xb1a000,0x1000),(0x11d4000,0x1000),
                  (0x418000,0x1000),(0x7c1000,0x1000),(0x40f000,0x1000)]:
   self.u.mem_map(va,size)
   self.u.mem_write(va,game.get_data(va-0x400000,size))
  p=pefile.PE(str(dll_file))
  if dll_base!=p.OPTIONAL_HEADER.ImageBase:p.relocate_image(dll_base)
  self.u.mem_map(dll_base,(p.OPTIONAL_HEADER.SizeOfImage+4095)&~4095)
  self.u.mem_write(dll_base,p.get_memory_mapped_image())
  self.ex={x.name.decode():dll_base+x.address for x in p.DIRECTORY_ENTRY_EXPORT.symbols}
  self.u.mem_write(0x7e8dea,b'\xe9'+pack(self.ex['gender_stub']-0x7e8def))
  self.w(self.ex['gender_resume'],0x7e8def)
  self.u.mem_write(0x7e43a1,b'\xe9'+pack(self.ex['generated_stub']-0x7e43a6)+b'\x90')
  self.w(self.ex['generated_resume'],0x7e43a7)
  self.imports={};nextstub=STUB+0x100
  for desc in p.DIRECTORY_ENTRY_IMPORT:
   for imp in desc.imports:
    self.w(imp.address,nextstub)
    self.imports[nextstub]=imp.name.decode() if imp.name else str(imp.ordinal)
    self.u.mem_write(nextstub,b'\xc3');nextstub+=16
  self.virtual={STUB:'create',STUB+0x10:'nid',STUB+0x20:'pd_get',
                STUB+0x30:'pd_set',STUB+0x40:'factory',STUB+0x50:'age',STUB+0x60:'sex',
                STUB+0x70:'species',STUB+0x80:'get_species',STUB+0x90:'species_event',
                STUB+0xa0:'mask',STUB+0xb0:'randomize',STUB+0xc0:'get_sex',STUB+0xd0:'get_age'}
  self.choices=[];self.dialogs=[];self.writes=[];self.creations=[]
  self.language=language;self.dialog_proc=None;self.end_results=[];self.window_results={}
  self.w(0x14ac40c,D+0xd00 if language is not None else 0)
  self.w(D+0xd00,0x12e2070 if language!='unknown_manager' else 0)
  self.w(D+0xd30,language if isinstance(language,int) else 1)
  self.now=100;self.nid=80;self.result=80;self.parent_sex=0;self.rng_calls=0;self.dialog_delay=0;self.dialog_natural=0;self.resolver_calls=0;self.random_sex=1;self.random_age=0x20
  self.w(D+0x100+0x18,STUB) # creation interface virtual table
  self.w(D+0x500,D+0x600) # neighbour -> vtable
  self.w(D+0x600+0x20,STUB+0x10)
  self.w(D+0x600+0x40,STUB+0x20)
  self.w(D+0x600+0x44,STUB+0x30)
  self.w(D+0x700,D+0x800) # factory -> vtable
  self.w(D+0x800+0x0c,STUB+0x40)
  self.w(D+0x900,D+0xa00) # appearance builder -> vtable
  self.w(D+0xa00+0xc8,STUB+0x50)
  self.w(D+0xa00+0xcc,STUB+0x60)
  for offset,stub in [(0xd0,0x70),(0x60,0x80),(0x110,0xa0),(0x188,0xb0),(0x5c,0xc0),(0x58,0xd0)]:
   self.w(D+0xa00+offset,STUB+stub)
  self.w(D+0x1100,D+0x1200);self.w(D+0x1200+0x11c,STUB+0x90)
  # Leave the real random call in place; its return value is a controlled double.
  self.u.mem_write(0x418038,b'\xdd\x05'+pack(D+0xb00)+b'\xc3')
  self.u.hook_add(UC_HOOK_CODE,self.hook)
 def w(self,a,n):self.u.mem_write(a,pack(n))
 def r(self,a):return struct.unpack('<I',self.u.mem_read(a,4))[0]
 def reg(self,r):return self.u.reg_read(r)
 def args(self,n):return [self.r(self.reg(UC_X86_REG_ESP)+4+4*i) for i in range(n)]
 def ret(self,value=0,pop=0):
  sp=self.reg(UC_X86_REG_ESP);target=self.r(sp)
  self.u.reg_write(UC_X86_REG_EAX,value&0xffffffff)
  self.u.reg_write(UC_X86_REG_ESP,sp+4+pop)
  self.u.reg_write(UC_X86_REG_EIP,target)
 def hook(self,u,a,size,data):
  if a==0x7e8dea:self.dialog_natural=self.r(S+0x18)
  if a==0x7e43a1:self.dialog_natural=self.r(D+0x0c)
  if a in self.imports:
   name=self.imports[a]
   if name in ['EnterCriticalSection','LeaveCriticalSection']:return self.ret(0,4)
   if name=='GetTickCount':return self.ret(self.now)
   if name in ['GetActiveWindow','GetForegroundWindow']:return self.ret(0)
   if name=='GetCurrentProcessId':return self.ret(123)
   if name=='GetModuleHandleW':return self.ret(0x400000,4)
   if name=='GetWindowLongW':return self.ret(0,8)
   if name=='SetWindowLongW':
    window,index,value=self.args(3);self.window_results[index]=value;return self.ret(0,12)
   if name=='EndDialog':self.end_results.append(self.args(2)[1]);return self.ret(1,8)
   if name=='GetTempPathW':return self.ret(0,8) # suppress test logging
   if name=='DialogBoxIndirectParamW':
    args=self.args(5);template=bytes(u.mem_read(args[1],3072));self.dialog_proc=args[3]
    german=self.language in [4,39]
    keep='Beibehalten' if german else 'Keep'
    assert keep.encode('utf-16-le')+b'\0\0' in template
    female=('Das Spiel hat für dieses Baby ein Mädchen gewählt.' if german else 'The game has chosen a girl for this baby.').encode('utf-16-le')+b'\0\0'
    male=('Das Spiel hat für dieses Baby einen Jungen gewählt.' if german else 'The game has chosen a boy for this baby.').encode('utf-16-le')+b'\0\0'
    assert (female in template) != (male in template)
    assert (female in template) == (self.dialog_natural==1)
    opposite=('In Junge ändern' if female in template else 'In Mädchen ändern') if german else ('Change to boy' if female in template else 'Change to girl')
    assert opposite.encode('utf-16-le')+b'\0\0' in template
    assert 'Mod by Mishka Midsummer'.encode('utf-16-le')+b'\0\0' in template
    hint='Bei Mehrlingen folgt eine Auswahl pro Baby.' if german else 'For multiple births, you can choose separately for each baby.'
    assert hint.encode('utf-16-le')+b'\0\0' in template
    assert struct.unpack_from('<H',template,8)[0]==7
    assert struct.unpack_from('<I',template,0)[0]&0xc00000==0 # no Windows title bar
    assert self.choices,'unexpected dialogue'
    chosen=self.choices.pop(0);self.dialogs.append(chosen)
    assert chosen in [0,-1,2 if female in template else 1]
    self.now=(self.now+self.dialog_delay)&0xffffffff
    # Simulate a UI routine disturbing SIMD and floating-point control state.
    u.reg_write(UC_X86_REG_XMM0,0x1234)
    u.reg_write(UC_X86_REG_MXCSR,0x1f80)
    u.reg_write(UC_X86_REG_FPCW,0x37f)
    return self.ret(chosen,20)
   if name=='memset':
    dest,val,n=self.args(3);u.mem_write(dest,bytes([val&255])*n);return self.ret(dest)
   if name=='memcpy':
    dest,src,n=self.args(3);u.mem_write(dest,bytes(u.mem_read(src,n)));return self.ret(dest)
   if name=='memcmp':
    x,y,n=self.args(3);xb=bytes(u.mem_read(x,n));yb=bytes(u.mem_read(y,n));return self.ret((xb>yb)-(xb<yb))
   raise AssertionError(('unexpected import',name,hex(a)))
  if a==0x418038:self.rng_calls+=1;return
  if a==0x7c12b0:return self.ret(1) # species-to-person-data conversion, cdecl
  if a==0x40f318:return self.ret(D+0x700)
  if a not in self.virtual:return
  name=self.virtual[a]
  if name=='create':
   self.creations.append(self.args(4))
   assert self.reg(UC_X86_REG_ECX)==D+0x200
   return self.ret(self.result,16)
  if name=='nid':return self.ret(self.nid)
  if name=='pd_get':assert self.args(1)==[0x41];return self.ret(self.parent_sex,4)
  if name=='pd_set':self.writes.append(('person',*self.args(2)));return self.ret(0,8)
  if name=='factory':
   _,_,out=self.args(3);self.w(out,D+0x900);return self.ret(1,12)
  if name in ['age','sex','species']:self.writes.append((name,*self.args(1)));return self.ret(0,4)
  if name=='get_species':return self.ret(1)
  if name in ['species_event','mask']:return self.ret(0,4)
  if name=='randomize':self.resolver_calls+=1;return self.ret(0,8)
  if name=='get_sex':return self.ret(self.random_sex)
  if name=='get_age':return self.ret(self.random_age)
 def record(self,nid=80,p1=1,p2=2,node=NODE):
  self.result=nid;self.nid=nid
  self.u.mem_write(D+0x300,node)
  for i,v in enumerate([p1,p2,0x7fd96b54,0]):self.w(S+4*i,v)
  self.w(S+0x20,D+0x300)
  regs={UC_X86_REG_EAX:0x12345678,UC_X86_REG_EBX:D+0x100,
        UC_X86_REG_ECX:D+0x200,UC_X86_REG_EDX:0x44332211,
        UC_X86_REG_EBP:0x11112222,UC_X86_REG_ESI:0x55556666,
        UC_X86_REG_EDI:0x77778888,UC_X86_REG_ESP:S,UC_X86_REG_EFLAGS:0x202}
  for r,v in regs.items():self.u.reg_write(r,v)
  end=0xb1a7f8 if nid==-1 else 0xb1a7e6
  self.u.emu_start(0xb1a7de,end,count=100000)
  assert self.reg(UC_X86_REG_EIP)==end
  assert self.reg(UC_X86_REG_ESP)==S+16
  assert self.reg(UC_X86_REG_EAX)==nid&0xffffffff
  for r in [UC_X86_REG_EBX,UC_X86_REG_EBP,UC_X86_REG_ESI,UC_X86_REG_EDI]:
   assert self.reg(r)==regs[r]
  assert self.creations[-1]==[p1,p2,0x7fd96b54,0]
 def sex(self,nid=80,p1=1,p2=2,choice=None,random_value=.25,stop=0x7e8e9a,species=1,neighbour=True):
  self.nid=nid
  if choice is not None:self.choices.append(choice)
  for i,v in enumerate([1,p1,p2,species,0,D+0x500 if neighbour else 0,0,0]):self.w(D+i*4,v)
  self.w(S+0x14,D+0xc00);self.w(S+0x20,p2);self.w(S+0x24,p1)
  self.u.mem_write(D+0xb00,struct.pack('<d',random_value))
  for r,v in {UC_X86_REG_ESP:S,UC_X86_REG_ESI:D,UC_X86_REG_EDI:D+0x500,
              UC_X86_REG_EBX:0,UC_X86_REG_EBP:0x12345678,UC_X86_REG_EFLAGS:0x202}.items():
   self.u.reg_write(r,v)
  self.u.reg_write(UC_X86_REG_XMM0,0xdeadbeef123456789abcdef)
  self.u.reg_write(UC_X86_REG_MXCSR,0x3f80)
  self.u.reg_write(UC_X86_REG_FPCW,0x27f)
  self.writes=[]
  # Real switch dispatch and phase advance precede the gender block.
  self.u.emu_start(0x7e8bed,0x7e8cf2,count=1000)
  assert self.r(D)==2
  self.u.reg_write(UC_X86_REG_EFLAGS,0x202)
  self.u.emu_start(0x7e8d99,stop,count=200000)
  assert self.reg(UC_X86_REG_EIP)==stop,hex(self.reg(UC_X86_REG_EIP))
  assert self.reg(UC_X86_REG_XMM0)==0xdeadbeef123456789abcdef
  assert self.reg(UC_X86_REG_MXCSR)==0x3f80
  assert self.reg(UC_X86_REG_FPCW)==0x27f
  assert not self.choices
  if stop==0x7e8def:
   assert self.reg(UC_X86_REG_ESP)==S
   assert self.reg(UC_X86_REG_ESI)==D
   assert self.reg(UC_X86_REG_EDI)==D+0x500
   assert self.reg(UC_X86_REG_EBP)==0x12345678
   assert self.reg(UC_X86_REG_EBX)==0
   assert self.reg(UC_X86_REG_ECX)==D+0x500
   assert self.reg(UC_X86_REG_EDX)==D+0x600
   return self.r(S+0x18)
  gender=next(v[1] for v in self.writes if v[0]=='sex')
  assert ('person',0x41,1 if gender==1 else 0) in self.writes
  assert ('age',0x20) in self.writes
  assert self.reg(UC_X86_REG_ESP)==S
  return gender
 def assert_next_phase(self,general=False):
  self.u.reg_write(UC_X86_REG_ESI,D)
  start,end=(0x7e4254,0x7e44a3) if general else (0x7e8bed,0x7e8f16)
  count=len(self.dialogs)
  self.u.emu_start(start,end,count=1000)
  assert self.reg(UC_X86_REG_EIP)==end
  assert len(self.dialogs)==count
 def general(self,choice=None,age=0x20,species=0,gender=-1,random_sex=1,random_age=0x20,stop=0x7e445a):
  self.random_sex=random_sex;self.random_age=random_age
  if choice is not None:self.choices.append(choice)
  for i,v in enumerate([1,species,age,gender,0,0,0,D+0x500,0,D+0x900,0]):self.w(D+i*4,v)
  self.w(S+0x18,D+0x1100)
  regs={UC_X86_REG_ESP:S,UC_X86_REG_ESI:D,UC_X86_REG_EDI:0x11223344,
        UC_X86_REG_EBP:0x12345678,UC_X86_REG_EBX:0,UC_X86_REG_EFLAGS:0x202}
  for r,v in regs.items():self.u.reg_write(r,v)
  self.u.reg_write(UC_X86_REG_XMM0,0xdeadbeef123456789abcdef)
  self.u.reg_write(UC_X86_REG_MXCSR,0x3f80);self.u.reg_write(UC_X86_REG_FPCW,0x27f)
  self.writes=[]
  # Execute the actual phase dispatch, resolution calls, both setters and PD writes.
  self.u.emu_start(0x7e4254,stop,count=200000)
  assert self.reg(UC_X86_REG_EIP)==stop,hex(self.reg(UC_X86_REG_EIP))
  assert self.r(D)==2 and self.reg(UC_X86_REG_ESP)==S
  for r in [UC_X86_REG_ESI,UC_X86_REG_EDI,UC_X86_REG_EBP]:assert self.reg(r)==regs[r]
  assert self.reg(UC_X86_REG_XMM0)==0xdeadbeef123456789abcdef
  assert self.reg(UC_X86_REG_MXCSR)==0x3f80 and self.reg(UC_X86_REG_FPCW)==0x27f
  assert not self.choices
  selected=self.r(D+0x0c)
  if stop==0x7e43a7:
   assert self.reg(UC_X86_REG_ECX)==D+0x900
   assert self.reg(UC_X86_REG_EDX)==self.r(D+8)
   assert self.reg(UC_X86_REG_EBX)==0xffffffff
  else:
   assert ('sex',selected) in self.writes
   assert ('person',0x41,1 if selected==1 else 0) in self.writes
   assert ('age',self.r(D+8)) in self.writes
   if self.r(D+8)==0x20:assert ('person',0x3a,1) in self.writes
  self.assert_next_phase(general=True)
  return selected
 def selector_guard(self,general,phase=2,species=None,age=0x20,natural=1,neighbour=0,nid=80):
  self.nid=nid
  state=[phase,0 if general else 1,age,1,0,0,0,0]
  if general:
   state[1]=species if species is not None else 0;state[7]=neighbour
  else:
   state[3]=species if species is not None else 1;state[5]=neighbour
  for i,v in enumerate(state):self.w(D+4*i,v)
  end=STUB+0xff00
  for i,v in enumerate([end,D,natural]):self.w(S+4*i,v)
  self.u.reg_write(UC_X86_REG_ESP,S)
  self.u.emu_start(self.ex['select_generated_sex@8' if general else 'select_sex@8'],end,count=100000)
  assert self.reg(UC_X86_REG_ESP)==S+12 and self.reg(UC_X86_REG_EAX)==natural
  assert not self.dialogs
 def message(self,msg,wp=0):
  assert self.dialog_proc
  stack=S+0x2000;end=STUB+0xff00
  for i,v in enumerate([end,0xabc,msg,wp,0]):self.w(stack+i*4,v)
  self.u.reg_write(UC_X86_REG_ESP,stack)
  self.u.emu_start(self.dialog_proc,end,count=100000)
  assert self.reg(UC_X86_REG_EIP)==end
  assert self.reg(UC_X86_REG_ESP)==stack+20
  return self.reg(UC_X86_REG_EAX)

for rv,natural in [(.25,1),(.75,2)]:
 for choice in [0,3-natural,-1]:
  m=Machine();got=m.sex(choice=choice,random_value=rv)
  assert got==(choice if choice in [1,2] else natural),(rv,choice,got)
  assert m.rng_calls==1 and len(m.dialogs)==1
  m.assert_next_phase()
print('PASS: genetic creation without a birth queue; real phase advance, both RNG outcomes, matching person/appearance gender, keep/change/error and next-phase dispatch')

for natural in [1,2]:
 for choice in [0,3-natural,-1]:
  for gender in [-1,natural]:
   m=Machine();got=m.general(choice=choice,gender=gender,random_sex=natural)
   assert got==(choice if choice in [1,2] else natural)
   assert m.resolver_calls==(1 if gender==-1 else 0)
   assert len(m.dialogs)==1
m=Machine();assert m.general(choice=2,age=-1,gender=-1)==2 and m.resolver_calls==2
print('PASS: general creation; real age/gender resolver calls, human baby test, state gender shared by appearance/PD, including randomly resolved baby age; no second dialog in the next phase')

for language in [1,4,39,3,6,0,999,None,'unknown_manager']:
 for natural in [1,2]:
  m=Machine(language=language);assert m.sex(choice=3-natural,random_value=.25 if natural==1 else .75)==3-natural
  m=Machine(language=language);assert m.general(choice=3-natural,random_sex=natural)==3-natural
print('PASS: German only for German game languages, English fallback, both sexes and exact credit in both creation routes')

m=Machine();m.sex(choice=0)
for message,wp,value in [(0x111,101,1),(0x111,102,2),(0x111,103,0),(0x111,2,0),(0x111,1,0),(0x10,0,0)]:
 assert m.message(message,wp)==1 and m.end_results[-1]==value
assert m.message(0x400)==1 and m.window_results[0]==((0x534b<<16)|103)
print('PASS: existing compiled dialog choice/keep/close/default-button behavior')

# Recorded from supplied objects.package. These formerly failed the exact home-birth filter.
operands={
 'home birth':'00000019000001000007000000000000',
 'new adoptive baby':'01000219080019070007000000000000',
 'Tombstone Make Baby From Neighbor ID':'000000121f00121f0007000000000000',
}
for label,operand in operands.items():
 m=Machine();m.record(node=NODE[:4]+bytes.fromhex(operand)+NODE[20:]);assert m.sex(choice=2)==2
 assert bytes(m.u.mem_read(0xb1a7de,8))==bytes.fromhex('ff531883f8ff7412')
print('PASS: original creation call remains unpatched; home/adoption/debug-BHAV operands no longer gate the genetic selector')

m=Machine();m.dialog_delay=600000
for i in range(70):
 m.record(nid=80+i);assert m.sex(nid=80+i,choice=2 if i%2 else 0)==(2 if i%2 else 1)
 m.assert_next_phase()
assert len(m.dialogs)==70
print('PASS: independent choices beyond the old 64-entry queue and 5-minute timeout')

for parent_sex in [0,1]:
 for choice in [0,1 if parent_sex else 2]:
  m=Machine();m.parent_sex=parent_sex
  assert m.sex(p2=1,choice=choice)==(choice or (2 if parent_sex else 1))
print('PASS: same-parent special case still displays the actual game result and permits changing it')

for species in [1,2,3,4,0xffffffff]:
 m=Machine();assert m.general(species=species)==1 and not m.dialogs
for age in [0,1,2,4,8,0x10,0x40,0x60]:
 m=Machine();assert m.general(age=age)==1 and not m.dialogs
for species in [0,2,4,8,0xffffffff]:
 m=Machine();assert m.sex(species=species)==1 and not m.dialogs
for general in [False,True]:
 for phase in [0,1,3,4,0xffffffff]:Machine().selector_guard(general,phase=phase,neighbour=D+0x500)
 for natural in [0,3,0xffffffff]:Machine().selector_guard(general,natural=natural,neighbour=D+0x500)
 for nid in [0,0xffff]:Machine().selector_guard(general,nid=nid,neighbour=D+0x500)
 Machine().selector_guard(general,neighbour=0)
print('PASS: pets, general non-baby ages, invalid phases/genders, missing neighbour and invalid NIDs retain the original value without a dialog')

for base in [0x10000000,0x30000000]:
 m=Machine(base);assert m.sex(choice=2,stop=0x7e8def)==2
 m=Machine(base);assert m.general(choice=2,stop=0x7e43a7)==2
print('PASS: both compiled hook ABIs, stack balance, nonvolatile registers, x87/SIMD state and relocated DLL')
print('ASI SHA256:',hashlib.sha256(DLL.read_bytes()).hexdigest())
print('LIMIT: Windows APIs and unrelated engine methods are test doubles. No live game, saved character, adoption delivery or Monique crib test was run.')
