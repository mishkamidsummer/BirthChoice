#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
# Python package ziglang==0.13.0 provides the cross compiler and Windows headers.
python -m ziglang cc -target x86-windows-gnu -O2 -Wall -Wextra -Werror \
  -fno-omit-frame-pointer -shared src/birth_choice.c src/dialog_ui.c src/dialog_theme.c src/ui_assets.c src/hooks.S src/exports.def \
  -o MishkaMidsummer_BabyGenderChoice.asi -luser32 -lkernel32 -lgdi32 -lmsimg32

