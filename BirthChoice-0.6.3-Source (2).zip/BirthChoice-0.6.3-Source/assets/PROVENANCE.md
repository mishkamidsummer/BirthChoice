# Asset provenance

## Font

The original font comes from the base-game font directory in oduska's [HomeCrafter Plus Portable](https://modthesims.info/d/699956/the-sims-2-homecrafter-plus-portable-version.html).

The game's `FontStyle.ini` assigns Benguiat Bold to popup headings and generic buttons. BirthChoice uses it for all dialog text. Font metadata credits the game adaptation to Christian Stratton for Maxis/Electronic Arts, 2003.

| Original file | SHA-256 |
|---|---|
| ITC Benguiat Gothic (bold).mxf | dde076d74f47025af8a6b848bef33828d808fb5f365903fc838519b4c18f46d3 |

`tools/convert_game_font.py` converts Type 1 glyphs into an OpenType/CFF subset for GDI, with the private family name `BirthChoice Sims2 Heading`. The 103 included glyph outlines and advances match the originals. Copyright notices remain embedded in the font.

Original typeface: **ITC Benguiat Gothic**, International Typeface Corporation and Adobe. Game adaptation: **Maxis/Electronic Arts**.

The original MXF, full font and HomeCrafter executable are not included.

References: [MXF format](https://www.wiki.sc4devotion.com/index.php?title=MXF), [OpenTS2 font decoding discussion](https://github.com/LazyDuchess/OpenTS2/issues/55).

## Plumbob

`sims2-plumbob.png` is the first upright frame of `plumbob.ani` from [Requested by MSW—Plumbob Cursor](https://modthesims.info/d/249765/requested-by-msw-plumbob-cursor.html), uploaded by **i like cheesey oranges** on 20 September 2007. The creator credits **EA** for the artwork.

| Resource | SHA-256 |
|---|---|
| Original plumbob.ani | 7b55547e7dba57812d3a5627f2068817dfccfdc421842721826268e24070e616 |
| sims2-plumbob.png | 14817d173b974dd4d29ed5c7f347a76d8f80916ea5d5fd54bedc8ccf7269d3c5 |

The 32×32 frame retains its original transparency and is embedded as premultiplied BGRA for Windows AlphaBlend. The complete cursor mod is not included.
