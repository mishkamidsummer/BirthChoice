# BirthChoice

Baby gender choice for **The Sims 2**, by **Mishka Midsummer**.

Keep the game's choice or change it before a newly generated human baby finishes creation. Each baby gets a separate choice. The dialog supports English and German.

Version 0.6.3 includes profiles for the supported UC/EP9 executable, EA Legacy **1.18.0.189** and Steam Legacy **1.18.0.187**. The plugin selects its profile automatically and rejects unrecognized builds.

## Development

- [BUILDING.md](BUILDING.md) — compile the 32-bit Windows ASI and run verification.
- [Code map](docs/CODE_MAP.md) — source layout.
- [Steam port](docs/STEAM_PORT.md) — addresses, hooks and build guards.
- [Testing status](docs/TESTING_STATUS.md) — gameplay reports and emulator results.
- [Credits](CREDITS.md), [asset provenance](assets/PROVENANCE.md) and [licensing](LICENSING.md).

Developed with OpenAI Codex assistance.
