"""Inspect BirthChoice's restricted Legacy code snapshot (not a full process dump)."""
from pathlib import Path
import argparse
import hashlib
import json
import struct

EXPECTED = [(b'.text', 0x1000, 0xf472ae), (b'.rdata', 0xf49000, 0x29c9b8)]


def load_capture(data):
    if len(data) < 60:
        raise ValueError('Incomplete snapshot header')
    magic, version, base, image_size, timestamp, count = struct.unpack_from('<8s5I', data)
    if (magic, version, image_size, timestamp, count) != (
        b'BCLC0001', 1, 0x1417000, 0x67f41f02, 2
    ):
        raise ValueError('Unknown snapshot format or unsupported game')
    if not base or base + image_size > 0xffffffff:
        raise ValueError('Invalid 32-bit module range')
    sections = []
    offset = 60
    for i, expected in enumerate(EXPECTED):
        name, rva, size = struct.unpack_from('<8sII', data, 28 + i * 16)
        name = name.rstrip(b'\0')
        if (name, rva, size) != expected:
            raise ValueError('Unexpected section: only the profiled .text/.rdata are allowed')
        if offset + size > len(data):
            raise ValueError('Incomplete section')
        sections.append({'name': name.decode(), 'rva': rva, 'data': data[offset:offset+size]})
        offset += size
    if offset != len(data):
        raise ValueError('Unexpected trailing data')
    return {'base': base, 'image_size': image_size, 'timestamp': timestamp, 'sections': sections}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('capture', type=Path)
    args = parser.parse_args()
    raw = args.capture.read_bytes()
    image = load_capture(raw)
    print(json.dumps({
        'sha256': hashlib.sha256(raw).hexdigest(),
        'image_base': hex(image['base']), 'image_size': hex(image['image_size']),
        'timestamp': hex(image['timestamp']),
        'sections': [{'name': s['name'], 'rva': hex(s['rva']), 'size': len(s['data']),
                      'sha256': hashlib.sha256(s['data']).hexdigest()} for s in image['sections']]
    }, indent=2))
