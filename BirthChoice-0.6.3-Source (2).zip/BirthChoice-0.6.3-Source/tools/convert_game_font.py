"""Convert the original game MXF's Type 1 outlines to a private OTF subset.

Usage: python tools/convert_game_font.py original.mxf output.otf
Requires fontTools. No Windows font installation or game-file edits.
"""
from pathlib import Path
import argparse
import tempfile
from fontTools import agl
from fontTools.t1Lib import T1Font
from fontTools.fontBuilder import FontBuilder
from fontTools.pens.boundsPen import BoundsPen
from fontTools.pens.t2CharStringPen import T2CharStringPen

FACES = {
    'ITCBenguiatGothic-Bold': ('BirthChoice Sims2 Heading', 'Bold', 700),
    'HelveticaNeueLTStd-Medium': ('BirthChoice Sims2 Body', 'Regular', 500),
}

def convert(source, destination):
    data = source.read_bytes()
    if data[:8] != b'MXFN\x02bZ\0':
        raise ValueError('Expected an original Maxis MXF font')
    raw = bytes(b ^ data[8] for b in data[9:])
    pos = 0
    while raw[pos:pos+2] in (b'\x80\x01', b'\x80\x02'):
        length = int.from_bytes(raw[pos+2:pos+6], 'little')
        if pos + 6 + length > len(raw):
            raise ValueError('Truncated Type 1 segment')
        pos += 6 + length
    if raw[pos:pos+2] != b'\x80\x03':
        raise ValueError('Missing Type 1 end marker')
    with tempfile.TemporaryDirectory(prefix='birthchoice-font-') as temp:
        pfb = Path(temp)/'font.pfb'
        pfb.write_bytes(raw[:pos+2])
        original = T1Font(str(pfb), encoding='latin1')
        original.parse()
        glyph_set = original.getGlyphSet()
        family, style, weight = FACES[original.font['FontName']]
        info = original.font['FontInfo']
        wanted = set(range(32, 127)) | set(map(ord, '\u00a0ÄÖÜäöüß'))
        cmap = {}
        for name in glyph_set:
            unicode = agl.toUnicode(name)
            if len(unicode) == 1 and ord(unicode) in wanted:
                cmap[ord(unicode)] = name
        # Type 1 encodings commonly use the same space for U+00A0.
        cmap[160] = cmap[32]
        if wanted - cmap.keys():
            raise ValueError(f'Missing characters: {wanted - cmap.keys()}')
        glyphs = ['.notdef'] + sorted(set(cmap.values()))
        metrics, charstrings = {}, {}
        for name in glyphs:
            glyph = glyph_set[name]
            bounds = BoundsPen(glyph_set)
            glyph.draw(bounds)
            pen = T2CharStringPen(glyph.width, glyph_set, roundTolerance=0)
            glyph.draw(pen)
            charstrings[name] = pen.getCharString()
            left = round(bounds.bounds[0]) if bounds.bounds else 0
            metrics[name] = (round(glyph.width), left)
        ascent, descent = original.font['FontBBox'][3], original.font['FontBBox'][1]
        ps_name = family.replace(' ', '') + '-' + style
        builder = FontBuilder(1000, isTTF=False)
        builder.setupGlyphOrder(glyphs)
        builder.setupCharacterMap(cmap)
        builder.setupCFF(ps_name, {
            'FullName': family + ' ' + style, 'FamilyName': family,
            'Weight': info['Weight'], 'version': '001.000',
            'Notice': info['Notice'], 'Copyright': info.get('Copyright', ''),
            'FontMatrix': original.font['FontMatrix'],
            'ItalicAngle': info['ItalicAngle'],
            'UnderlinePosition': info['UnderlinePosition'],
            'UnderlineThickness': info['UnderlineThickness'],
        }, charstrings, {})
        builder.setupHorizontalMetrics(metrics)
        builder.setupHorizontalHeader(ascent=ascent, descent=descent, lineGap=0)
        builder.setupNameTable({
            'familyName': family, 'styleName': style,
            'uniqueFontIdentifier': 'BirthChoice-0.4-' + ps_name,
            'fullName': family + ' ' + style, 'psName': ps_name,
            'version': 'Version 1.000',
            'copyright': info['Notice'] + '\n' + info.get('Copyright', ''),
            'description': 'Original Sims 2 glyph outlines; private dialog subset.',
        })
        builder.setupOS2(sTypoAscender=ascent, sTypoDescender=descent,
                         sTypoLineGap=0, usWinAscent=ascent, usWinDescent=-descent,
                         usWeightClass=weight, fsSelection=32 if weight==700 else 64)
        builder.setupPost()
        builder.font['head'].macStyle = 1 if weight==700 else 0
        builder.font['head'].created = builder.font['head'].modified = 3789417600
        builder.save(destination)
        print(f'{original.font["FontName"]}: {len(glyphs)} original glyphs -> {destination}')

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('destination', type=Path)
    args = parser.parse_args()
    convert(args.source, args.destination)
