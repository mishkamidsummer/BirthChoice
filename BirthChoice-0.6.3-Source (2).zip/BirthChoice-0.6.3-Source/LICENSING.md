# Licensing

No project-wide license is included.

The font subset and plumbob are third-party assets, including their embedded copies in `src/ui_assets.c`. Their sources and original notices are documented in [assets/PROVENANCE.md](assets/PROVENANCE.md).
