#define WIN32_LEAN_AND_MEAN
#define UNICODE
#define _UNICODE
#include <windows.h>
#include <stdint.h>
#include "dialog_ui.h"
#include "dialog_theme.h"
#include "ui_assets.h"
#include "strings.h"

typedef struct {
    HFONT fonts[UI_FONT_COUNT];
    HANDLE font_resource;
    HBITMAP plumbob;
    WNDPROC buttons[3];
    HWND hover;
    int natural;
} DialogState;
typedef struct { HDC dc; DialogState *state; } PaintContext;
static unsigned last_asset_status;
unsigned birth_dialog_asset_status(void) { return last_asset_status; }

static void load_assets(HWND w,DialogState *state) {
    DWORD count=0;
    state->font_resource=AddFontMemResourceEx((void *)ui_font_heading,ui_font_heading_size,NULL,&count);
    unsigned verified=state->font_resource?3u:0u;
    HDC dc=GetDC(w);
    for(unsigned i=0;i<UI_FONT_COUNT;++i) {
        unsigned role=(i==UI_TITLE_FONT||i==UI_BUTTON_FONT)?0u:1u;
        const WCHAR *face=state->font_resource?UI_HEADING_FACE:L"Tahoma";
        state->fonts[i]=CreateFontW(-ui_font_sizes[i],0,0,0,FW_BOLD,
            FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_OUTLINE_PRECIS,CLIP_DEFAULT_PRECIS,
            ANTIALIASED_QUALITY,DEFAULT_PITCH|FF_SWISS,face);
        if(dc && state->fonts[i]) {
            WCHAR actual[LF_FACESIZE]={0};HGDIOBJ previous=SelectObject(dc,state->fonts[i]);
            if(!GetTextFaceW(dc,LF_FACESIZE,actual) || lstrcmpW(actual,face)!=0)
                verified&=~(1u<<role);
            SelectObject(dc,previous);
        } else verified&=~(1u<<role);
    }
    if(dc)ReleaseDC(w,dc);
    BITMAPINFO info={0};info.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);
    info.bmiHeader.biWidth=UI_PLUMBOB_WIDTH;info.bmiHeader.biHeight=-UI_PLUMBOB_HEIGHT;
    info.bmiHeader.biPlanes=1;info.bmiHeader.biBitCount=32;info.bmiHeader.biCompression=BI_RGB;
    void *pixels=NULL;
    state->plumbob=CreateDIBSection(NULL,&info,DIB_RGB_COLORS,&pixels,NULL,0);
    if(state->plumbob && pixels) {
        CopyMemory(pixels,ui_plumbob_pixels,sizeof ui_plumbob_pixels);verified|=4u;
    }
    last_asset_status=verified;
}

static COLORREF color(uint32_t c) { return RGB((c>>16)&255,(c>>8)&255,c&255); }
static void gdi_round(void *context,UiRect r,int radius,uint32_t top,uint32_t bottom,uint32_t edge) {
    HDC dc=((PaintContext *)context)->dc;
    if(top!=UI_NO_COLOR) {
        int saved=SaveDC(dc);
        POINT corners[3]={{r.x,r.y},{r.x+r.w,r.y+r.h},{r.x+radius*2,r.y+radius*2}};
        LPtoDP(dc,corners,3);
        HRGN clip=CreateRoundRectRgn(corners[0].x,corners[0].y,corners[1].x+1,corners[1].y+1,
                                     corners[2].x-corners[0].x,corners[2].y-corners[0].y);
        if(clip){ExtSelectClipRgn(dc,clip,RGN_AND);DeleteObject(clip);}
        int divisor=r.h>1?r.h-1:1;
        for(int y=0;y<r.h;++y) {
            int red=(int)((top>>16)&255)+((int)((bottom>>16)&255)-(int)((top>>16)&255))*y/divisor;
            int green=(int)((top>>8)&255)+((int)((bottom>>8)&255)-(int)((top>>8)&255))*y/divisor;
            int blue=(int)(top&255)+((int)(bottom&255)-(int)(top&255))*y/divisor;
            HBRUSH brush=CreateSolidBrush(RGB(red,green,blue));
            RECT row={r.x,r.y+y,r.x+r.w,r.y+y+1};
            FillRect(dc,&row,brush);DeleteObject(brush);
        }
        RestoreDC(dc,saved);
    }
    if(edge!=UI_NO_COLOR) {
        HPEN pen=CreatePen(PS_SOLID,1,color(edge));
        HGDIOBJ oldpen=SelectObject(dc,pen),oldbrush=SelectObject(dc,GetStockObject(NULL_BRUSH));
        RoundRect(dc,r.x,r.y,r.x+r.w,r.y+r.h,radius*2,radius*2);
        SelectObject(dc,oldbrush);SelectObject(dc,oldpen);DeleteObject(pen);
    }
}
static void gdi_line(void *context,int x,int y,int x2,int y2,uint32_t c,int width) {
    HDC dc=((PaintContext *)context)->dc;
    HPEN pen=CreatePen(PS_SOLID,width,color(c));HGDIOBJ old=SelectObject(dc,pen);
    MoveToEx(dc,x,y,NULL);LineTo(dc,x2,y2);
    SelectObject(dc,old);DeleteObject(pen);
}
static void gdi_image(void *context,UiRect r) {
    PaintContext *p=context;
    if(!p->state->plumbob)return;
    HDC source=CreateCompatibleDC(p->dc);if(!source)return;
    HGDIOBJ old=SelectObject(source,p->state->plumbob);
    BLENDFUNCTION blend={AC_SRC_OVER,0,255,AC_SRC_ALPHA};
    AlphaBlend(p->dc,r.x,r.y,r.w,r.h,source,0,0,UI_PLUMBOB_WIDTH,UI_PLUMBOB_HEIGHT,blend);
    SelectObject(source,old);DeleteDC(source);
}
static void gdi_text(void *context,UiRect r,const wchar_t *text,unsigned font,uint32_t c,unsigned align) {
    PaintContext *p=context;HDC dc=p->dc;
    HGDIOBJ old=SelectObject(dc,p->state->fonts[font]?p->state->fonts[font]:GetStockObject(DEFAULT_GUI_FONT));
    SetBkMode(dc,TRANSPARENT);SetTextColor(dc,color(c));
    UINT flags=DT_NOPREFIX|DT_WORDBREAK|DT_EDITCONTROL;
    flags|=align==UI_CENTER?DT_CENTER:(align==UI_RIGHT?DT_RIGHT:DT_LEFT);
    RECT rect={r.x,r.y,r.x+r.w,r.y+r.h},measure=rect;
    DrawTextW(dc,text,-1,&measure,flags|DT_CALCRECT);
    int height=measure.bottom-measure.top;
    if(height<r.h)rect.top+=(r.h-height)/2;
    DrawTextW(dc,text,-1,&rect,flags);
    SelectObject(dc,old);
}
static UiPainter painter(PaintContext *c) {
    UiPainter p={c,gdi_round,gdi_line,gdi_image,gdi_text};return p;
}
static void map_paint(HWND w,HDC dc,POINT origin) {
    RECT r;GetClientRect(w,&r);
    SetMapMode(dc,MM_ANISOTROPIC);
    SetWindowExtEx(dc,UI_WIDTH,UI_HEIGHT,NULL);
    SetViewportExtEx(dc,r.right,r.bottom,NULL);
    SetViewportOrgEx(dc,-origin.x,-origin.y,NULL);
}
static int button_index(HWND button) {
    int id=GetDlgCtrlID(button);return id==UI_KEEP?0:(id==UI_CLOSE?2:1);
}
static LRESULT CALLBACK button_proc(HWND w,UINT msg,WPARAM wp,LPARAM lp) {
    HWND parent=GetParent(w);
    DialogState *state=(DialogState *)GetWindowLongPtrW(parent,DWLP_USER);
    if(!state)return DefWindowProcW(w,msg,wp,lp);
    if(msg==WM_MOUSEMOVE && state->hover!=w) {
        HWND old=state->hover;state->hover=w;
        TRACKMOUSEEVENT track={sizeof track,TME_LEAVE,w,0};TrackMouseEvent(&track);
        if(old)InvalidateRect(old,NULL,FALSE);
        InvalidateRect(w,NULL,FALSE);
    } else if(msg==WM_MOUSELEAVE && state->hover==w) {
        state->hover=NULL;InvalidateRect(w,NULL,FALSE);
    } else if(msg==BM_SETSTYLE) {
        /* Preserve owner drawing when the dialog manager moves keyboard focus. */
        wp=(wp&~(WPARAM)0xf)|BS_OWNERDRAW;
    }
    WNDPROC previous=state->buttons[button_index(w)];
    return previous?CallWindowProcW(previous,w,msg,wp,lp):DefWindowProcW(w,msg,wp,lp);
}
static void position_dialog(HWND w,DialogState *state) {
    HDC dc=GetDC(w);int dpi=dc?GetDeviceCaps(dc,LOGPIXELSX):96;
    if(dc)ReleaseDC(w,dc);if(dpi<72)dpi=96;
    int width=MulDiv(UI_WIDTH,dpi,96),height=MulDiv(UI_HEIGHT,dpi,96);
    HWND owner=GetWindow(w,GW_OWNER);RECT anchor;
    MONITORINFO monitor={0};monitor.cbSize=sizeof monitor;
    if(!GetMonitorInfoW(MonitorFromWindow(owner?owner:w,MONITOR_DEFAULTTONEAREST),&monitor))
        SystemParametersInfoW(SPI_GETWORKAREA,0,&monitor.rcWork,0);
    if(!owner || !GetWindowRect(owner,&anchor))anchor=monitor.rcWork;
    int x=anchor.left+(anchor.right-anchor.left-width)/2;
    int y=anchor.top+(anchor.bottom-anchor.top-height)/2;
    if(x+width>monitor.rcWork.right)x=monitor.rcWork.right-width;
    if(y+height>monitor.rcWork.bottom)y=monitor.rcWork.bottom-height;
    if(x<monitor.rcWork.left)x=monitor.rcWork.left;
    if(y<monitor.rcWork.top)y=monitor.rcWork.top;
    SetWindowPos(w,NULL,x,y,width,height,SWP_NOZORDER|SWP_NOACTIVATE);
    HRGN region=CreateRoundRectRgn(0,0,width+1,height+1,MulDiv(36,dpi,96),MulDiv(36,dpi,96));
    if(region && !SetWindowRgn(w,region,TRUE))DeleteObject(region);
    const unsigned ids[]={UI_HEADING,UI_MESSAGE,UI_HINT,UI_CREDIT,UI_KEEP,
                          state->natural==1?UI_MALE:UI_FEMALE,UI_CLOSE};
    for(unsigned i=0;i<sizeof ids/sizeof ids[0];++i) {
        UiRect r=ui_control_rect(ids[i]);HWND control=GetDlgItem(w,(int)ids[i]);
        SetWindowPos(control,NULL,MulDiv(r.x,dpi,96),MulDiv(r.y,dpi,96),
                     MulDiv(r.w,dpi,96),MulDiv(r.h,dpi,96),SWP_NOZORDER|SWP_NOACTIVATE);
        if(i>=4)state->buttons[i-4]=(WNDPROC)SetWindowLongPtrW(control,GWLP_WNDPROC,(LONG_PTR)button_proc);
    }
}
static INT_PTR CALLBACK choose_proc(HWND w,UINT msg,WPARAM wp,LPARAM lp) {
    DialogState *state=(DialogState *)GetWindowLongPtrW(w,DWLP_USER);
    if(msg==WM_INITDIALOG) {
        state=(DialogState *)lp;SetWindowLongPtrW(w,DWLP_USER,(LONG_PTR)state);
        load_assets(w,state);
        position_dialog(w,state);SetFocus(GetDlgItem(w,UI_KEEP));return FALSE;
    }
    if(msg==WM_CLOSE || (msg==WM_COMMAND && LOWORD(wp)==UI_CLOSE)) {
        EndDialog(w,0);return TRUE;
    }
    if(msg==WM_COMMAND && HIWORD(wp)==BN_CLICKED) {
        switch(LOWORD(wp)) {
            case UI_FEMALE:EndDialog(w,1);return TRUE;
            case UI_MALE:EndDialog(w,2);return TRUE;
            case UI_KEEP:case IDOK:EndDialog(w,0);return TRUE;
        }
    }
    if(msg==DM_GETDEFID) {
        SetWindowLongPtrW(w,DWLP_MSGRESULT,MAKELONG(UI_KEEP,DC_HASDEFID));return TRUE;
    }
    if(msg==WM_ERASEBKGND)return TRUE;
    if(state && msg==WM_PAINT) {
        PAINTSTRUCT ps;HDC dc=BeginPaint(w,&ps);int saved=SaveDC(dc);
        map_paint(w,dc,(POINT){0,0});PaintContext context={dc,state};UiPainter p=painter(&context);
        ui_paint_background(&p);RestoreDC(dc,saved);EndPaint(w,&ps);return TRUE;
    }
    if(state && msg==WM_DRAWITEM) {
        DRAWITEMSTRUCT *draw=(DRAWITEMSTRUCT *)lp;
        int saved=SaveDC(draw->hDC);POINT origin={0,0};
        MapWindowPoints(draw->hwndItem,w,&origin,1);map_paint(w,draw->hDC,origin);
        PaintContext context={draw->hDC,state};UiPainter p=painter(&context);
        ui_paint_background(&p);
        WCHAR text[256];GetWindowTextW(draw->hwndItem,text,256);
        unsigned flags=(draw->itemState&ODS_FOCUS)?UI_FOCUS:0;
        if(draw->itemState&ODS_SELECTED)flags|=UI_PRESSED;
        if(state->hover==draw->hwndItem)flags|=UI_HOVER;
        ui_paint_control(&p,draw->CtlID,text,flags);
        RestoreDC(draw->hDC,saved);return TRUE;
    }
    if(msg==WM_LBUTTONDOWN) {
        /* The header can move the popup without exposing a Windows title bar. */
        RECT rect;GetClientRect(w,&rect);
        if((short)HIWORD(lp)<MulDiv(58,rect.bottom,UI_HEIGHT)) {
            ReleaseCapture();SendMessageW(w,WM_NCLBUTTONDOWN,HTCAPTION,0);return TRUE;
        }
    }
    return FALSE;
}
static WORD *put32(WORD *p,DWORD v){*p++=(WORD)v;*p++=(WORD)(v>>16);return p;}
static WORD *putstr(WORD *p,const WCHAR *s){while((*p++=(WORD)*s++)!=0){}return p;}
static WORD *control(WORD *p,unsigned id,WORD klass,const WCHAR *text) {
    p=(WORD *)(((uintptr_t)p+3)&~(uintptr_t)3);
    DWORD style=WS_CHILD|WS_VISIBLE|(klass==0x80?WS_TABSTOP|BS_OWNERDRAW:SS_OWNERDRAW);
    p=put32(p,style);p=put32(p,0);
    *p++=0;*p++=0;*p++=1;*p++=1;*p++=(WORD)id;
    *p++=0xffff;*p++=klass;p=putstr(p,text);*p++=0;return p;
}
INT_PTR birth_dialog(HINSTANCE module,HWND owner,int natural,unsigned language) {
    const BirthStrings *s=birth_strings(language);
    _Alignas(4) WORD buf[1536]={0};WORD *p=buf;
    last_asset_status=0;
    p=put32(p,WS_POPUP|WS_CLIPCHILDREN|DS_CENTER);p=put32(p,0);
    *p++=7;*p++=0;*p++=0;*p++=280;*p++=152;*p++=0;*p++=0;
    p=putstr(p,s->title);
    p=control(p,UI_HEADING,0x82,s->heading);
    p=control(p,UI_MESSAGE,0x82,natural==1?s->female:s->male);
    p=control(p,UI_HINT,0x82,s->hint);
    p=control(p,UI_CREDIT,0x82,BIRTH_CREDIT);
    p=control(p,UI_KEEP,0x80,s->keep);
    p=control(p,natural==1?UI_MALE:UI_FEMALE,0x80,natural==1?s->to_male:s->to_female);
    (void)control(p,UI_CLOSE,0x80,s->close);
    DialogState state={0};state.natural=natural;
    INT_PTR result=DialogBoxIndirectParamW(module,(DLGTEMPLATE *)buf,owner,choose_proc,(LPARAM)&state);
    for(unsigned i=0;i<UI_FONT_COUNT;++i)if(state.fonts[i])DeleteObject(state.fonts[i]);
    if(state.plumbob)DeleteObject(state.plumbob);
    if(state.font_resource)RemoveFontMemResourceEx(state.font_resource);
    return result;
}
