#ifndef BIRTH_UI_ASSETS_H
#define BIRTH_UI_ASSETS_H
#include <stdint.h>

#define UI_HEADING_FACE L"BirthChoice Sims2 Heading"
enum { UI_PLUMBOB_WIDTH=32, UI_PLUMBOB_HEIGHT=32 };
extern const unsigned char ui_font_heading[];
extern const unsigned ui_font_heading_size;
extern const uint32_t ui_plumbob_pixels[UI_PLUMBOB_WIDTH*UI_PLUMBOB_HEIGHT];
#endif
