#ifndef BIRTH_DIALOG_UI_H
#define BIRTH_DIALOG_UI_H
#include <windows.h>
INT_PTR birth_dialog(HINSTANCE module,HWND owner,int natural,unsigned language);
/* Last completed initialization: heading font=1, body font=2, plumbob=4. */
unsigned birth_dialog_asset_status(void);
#endif
