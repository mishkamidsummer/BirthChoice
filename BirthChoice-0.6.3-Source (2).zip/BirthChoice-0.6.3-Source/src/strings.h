#ifndef BIRTH_CHOICE_STRINGS_H
#define BIRTH_CHOICE_STRINGS_H
#include <wchar.h>

typedef struct {
    const wchar_t *title, *heading, *female, *male, *hint;
    const wchar_t *keep, *to_female, *to_male, *close;
} BirthStrings;

/* Engine language IDs, not Windows locale or installer language values.
 * 4 = German; 39 = Swiss German, normalized to German by the game. */
static const BirthStrings *birth_strings(unsigned language) {
    static const BirthStrings en = {
        L"Birth Choice", L"A baby is here!",
        L"The game has chosen a girl for this baby.",
        L"The game has chosen a boy for this baby.",
        L"For multiple births, you can choose separately for each baby.",
        L"Keep", L"Change to girl", L"Change to boy", L"Close"
    };
    static const BirthStrings de = {
        L"Geschlechtswahl bei der Geburt", L"Ein Baby ist da!",
        L"Das Spiel hat f\u00fcr dieses Baby ein M\u00e4dchen gew\u00e4hlt.",
        L"Das Spiel hat f\u00fcr dieses Baby einen Jungen gew\u00e4hlt.",
        L"Bei Mehrlingen folgt eine Auswahl pro Baby.",
        L"Beibehalten", L"In M\u00e4dchen \u00e4ndern", L"In Junge \u00e4ndern", L"Schlie\u00dfen"
    };
    return language == 4 || language == 39 ? &de : &en;
}
#define BIRTH_CREDIT L"Mod by Mishka Midsummer"
#endif
