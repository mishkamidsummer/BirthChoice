#define WIN32_LEAN_AND_MEAN
#define UNICODE
#define _UNICODE
#include <windows.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include "dialog_ui.h"

static HINSTANCE instance;
static volatile LONG dialog_open;
void *gender_resume;
void *generated_resume;
extern void generated_stub(void);
extern void gender_stub(void);
extern void legacy_gender_stub(void);
extern void legacy_generated_stub(void);
#include "build_profiles.h"
/* A selector can be reached only after successful guarded installation. */
static const BuildProfile *active_profile=&uc_profile;

static void log_line(const char *text) {
    WCHAR path[MAX_PATH];
    DWORD n = GetTempPathW(MAX_PATH, path);
    if (!n || n + 24 >= MAX_PATH) return;
    lstrcatW(path, L"Sims2BirthChoice.log");
    HANDLE f = CreateFileW(path, FILE_APPEND_DATA, FILE_SHARE_READ | FILE_SHARE_WRITE,
                          NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (f != INVALID_HANDLE_VALUE) {
        DWORD written;
        WriteFile(f, text, (DWORD)strlen(text), &written, NULL);
        CloseHandle(f);
    }
}

static char *append_text(char *p,const char *s) {
    while (*s) *p++=*s++;
    return p;
}
static char *append_hex(char *p,uint32_t value,unsigned digits) {
    static const char hex[]="0123456789ABCDEF";
    for (unsigned i=digits;i>0;--i) *p++=hex[(value>>((i-1)*4))&15];
    return p;
}
static void log_gender(uint16_t nid,int natural,const char *route) {
    char text[160],*p=text;
    p=append_text(p,"BC06 BABY child=");p=append_hex(p,nid,4);
    p=append_text(p," original=");p=append_hex(p,(uint32_t)natural,1);
    p=append_text(p," route=");p=append_text(p,route);
    p=append_text(p,"; opening choice\r\n");*p=0;log_line(text);
}

/* cGZLanguageManager cached interface, profiled separately for UC, EA Legacy and Steam Legacy.
 * The game has already resolved command-line/registry language by a birth.
 * Never use the Windows display language to choose the mod's strings. */
static unsigned game_language(void) {
    const uint8_t *base=(const uint8_t *)GetModuleHandleW(NULL);
    if(!base)return 1;
    const uint32_t *manager=*(const uint32_t *const *)(base+active_profile->language_cache);
    if(!manager || manager[0]!=(uintptr_t)(base+active_profile->language_vtable))return 1;
    return manager[active_profile->language_field/4];
}
static int ask_sex(int natural) {
    HWND owner=GetActiveWindow();
    if(!owner)owner=GetForegroundWindow();
    DWORD pid=0;
    if(owner)GetWindowThreadProcessId(owner,&pid);
    if(pid!=GetCurrentProcessId())owner=NULL;
    unsigned language=game_language();
    log_line(language==4 || language==39 ? "BC06 UI_LANGUAGE German (game).\r\n"
                                        : "BC06 UI_LANGUAGE English (default).\r\n");
    INT_PTR result=birth_dialog(instance,owner,natural,language);
    unsigned assets=birth_dialog_asset_status();
    log_line((assets&1)?"BC06 UI_FONT Heading: original Sims 2 Benguiat verified.\r\n"
                       :"BC06 UI_FONT Heading: original font unavailable; fallback.\r\n");
    log_line((assets&2)?"BC06 UI_FONT Body: original Sims 2 Benguiat verified.\r\n"
                       :"BC06 UI_FONT Body: original font unavailable; fallback.\r\n");
    log_line((assets&4)?"BC06 UI_PLUMBOB: original Sims 2 bitmap loaded.\r\n"
                       :"BC06 UI_PLUMBOB: bitmap unavailable.\r\n");
    if(result==-1)log_line("BC06 DIALOG_FAILED; keeping original gender.\r\n");
    return result==1 || result==2 ? (int)result : 0;
}

typedef int32_t (__attribute__((thiscall)) *GetNeighbourId)(void *self);
static int choose_new_baby(void *neighbour,int natural,const char *route) {
    if (!neighbour || (natural != 1 && natural != 2)) return natural;
    uintptr_t *vt=*(uintptr_t **)neighbour;
    /* The same +20h getter is used by both original creation methods. */
    uint16_t nid=(uint16_t)((GetNeighbourId)vt[0x20/4])(neighbour);
    if (!nid || nid==0xffff) return natural;
    if (InterlockedCompareExchange(&dialog_open,1,0) != 0) {
        log_line("BC06 DIALOG_BUSY; keeping original gender.\r\n");
        return natural;
    }
    log_gender(nid,natural,route);
    int chosen=ask_sex(natural);
    InterlockedExchange(&dialog_open,0);
    if (chosen == 1) log_line("BC06 CHOICE female (appearance=1, person data 41h=1).\r\n");
    else if (chosen == 2) log_line("BC06 CHOICE male (appearance=2, person data 41h=0).\r\n");
    else log_line("BC06 CHOICE original game result retained.\r\n");
    return chosen ? chosen : natural;
}

/* Genetic offspring processor: UC VA 007E8BB0 / EA RVA 00507840 / Steam RVA 00507600. Its phase-1 block advances to 2,
 * resolves gender, then unconditionally sets PD age 1 / appearance age 20h.
 * It is used by home birth, newly generated adoptive babies and other callers.
 * Species here is the appearance bitmask: human == 1. */
int __stdcall select_sex(const uint32_t *state, int natural) {
    if (!state || state[0] != 2 || state[3] != 1) return natural;
    return choose_new_baby((void *)(uintptr_t)state[5],natural,"GENETIC");
}

/* General new-character processor: UC VA 007E41E0 / EA RVA 005085F0 / Steam RVA 005083B0. Age/gender are already resolved
 * at this hook, before either appearance or person-data assignments.
 * Here species uses a DIFFERENT enumeration: human == 0, baby age == 20h.
 * This is a new-character state, not an existing Sim's load/age-up routine. */
int __stdcall select_generated_sex(const uint32_t *state, int natural) {
    if (!state || state[0] != 2 || state[1] != 0 || state[2] != 0x20)
        return natural;
    return choose_new_baby((void *)(uintptr_t)state[7],natural,"GENERAL");
}


int install_hooks(void) {
    uint8_t *base=(uint8_t *)GetModuleHandleW(NULL);
    if (!base) { log_line("Disabled: executable module unavailable.\r\n"); return 0; }
    IMAGE_DOS_HEADER *dos=(IMAGE_DOS_HEADER *)base;
    if (dos->e_magic != IMAGE_DOS_SIGNATURE || dos->e_lfanew < 0 || dos->e_lfanew > 0x1000) {
        log_line("Disabled: unrecognized executable header.\r\n"); return 0;
    }
    IMAGE_NT_HEADERS32 *nt=(IMAGE_NT_HEADERS32 *)(base+dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE || nt->FileHeader.Machine != IMAGE_FILE_MACHINE_I386 ||
        nt->OptionalHeader.Magic != 0x10b) {
        log_line("Disabled: executable is not the expected 32-bit Windows format.\r\n"); return 0;
    }
    const BuildProfile *profile=NULL;
    const BuildProfile *profiles[]={&uc_profile,&lc_profile,&steam_profile};
    for (unsigned i=0;i<COUNT(profiles);++i) {
        const BuildProfile *p=profiles[i];
        if (nt->FileHeader.TimeDateStamp==p->timestamp && nt->OptionalHeader.SizeOfImage==p->image_size &&
            (!p->entry_rva || nt->OptionalHeader.AddressOfEntryPoint==p->entry_rva)) {
            profile=p; break;
        }
    }
    if (!profile) { log_line("Disabled: this executable build is not supported.\r\n"); return 0; }
    log_line(profile->log_name);
    for (size_t i=0;i<profile->guard_count;++i) {
        const Guard *g=&profile->guards[i];
        if (memcmp(base+g->rva,g->bytes,g->size)) {
            log_line("Disabled: expected code differs (version, early loading or another patch).\r\n"); return 0;
        }
    }
    for (size_t i=0;i<profile->address_count;++i) {
        const AddressGuard *g=&profile->addresses[i];
        uint32_t found; memcpy(&found,base+g->rva,sizeof found);
        if (found!=(uint32_t)(uintptr_t)(base+g->target_rva)) {
            log_line("Disabled: expected relocated game address differs.\r\n"); return 0;
        }
    }
    HMODULE pinned;
    if (!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_PIN,
                           (LPCWSTR)(uintptr_t)profile->genetic_stub,&pinned)) {
        log_line("Disabled: cannot keep the plugin loaded.\r\n"); return 0;
    }
    uint8_t *sex=base+profile->genetic_rva, *generated=base+profile->general_rva;
    DWORD old_sex,old_generated,tmp;
    if (!VirtualProtect(sex,5,PAGE_EXECUTE_READWRITE,&old_sex)) {
        log_line("Disabled: cannot make genetic gender patch writable.\r\n"); return 0;
    }
    if (!VirtualProtect(generated,6,PAGE_EXECUTE_READWRITE,&old_generated)) {
        VirtualProtect(sex,5,old_sex,&tmp);
        log_line("Disabled: cannot make general gender patch writable.\r\n"); return 0;
    }
    active_profile=profile;
    gender_resume=sex+5;
    generated_resume=generated+6;
    /* x86 rel32 wraps modulo 2^32, including Legacy's high ASLR bases. */
    uint32_t delta=(uint32_t)((uintptr_t)profile->genetic_stub-(uintptr_t)(sex+5));
    sex[0]=0xe9; memcpy(sex+1,&delta,4);
    delta=(uint32_t)((uintptr_t)profile->general_stub-(uintptr_t)(generated+5));
    generated[0]=0xe9; memcpy(generated+1,&delta,4); generated[5]=0x90;
    FlushInstructionCache(GetCurrentProcess(),sex,5);
    FlushInstructionCache(GetCurrentProcess(),generated,6);
    VirtualProtect(sex,5,old_sex,&tmp);
    VirtualProtect(generated,6,old_generated,&tmp);
    log_line("BC06 HOOKS_ACTIVE: genetic and general baby creation hooks installed.\r\n");
    return 1;
}
BOOL WINAPI DllMain(HINSTANCE module,DWORD reason,LPVOID reserved) {
    (void)reserved;
    if (reason == DLL_PROCESS_ATTACH) {
        instance=module;
        log_line("\r\n=== BirthChoice 0.6.3-steam-test: ASI loaded ===\r\n");
        install_hooks();
    }
    return TRUE;
}
