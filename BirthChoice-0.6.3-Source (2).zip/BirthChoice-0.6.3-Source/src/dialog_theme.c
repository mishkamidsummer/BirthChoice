#include "dialog_theme.h"

UiRect ui_control_rect(unsigned id) {
    switch (id) {
        case UI_HEADING: return (UiRect){64,15,438,32};
        case UI_MESSAGE: return (UiRect){38,85,484,48};
        case UI_HINT: return (UiRect){32,146,496,20};
        case UI_KEEP: return (UiRect){28,201,244,48};
        case UI_FEMALE: case UI_MALE: return (UiRect){288,201,244,48};
        case UI_CREDIT: return (UiRect){26,273,508,16};
        case UI_CLOSE: return (UiRect){516,18,26,26};
        default: return (UiRect){0,0,0,0};
    }
}
static void panel(UiPainter *p,UiRect r,int radius,uint32_t a,uint32_t b,uint32_t edge) {
    p->rounded(p->context,r,radius,a,b,edge);
}
static void line(UiPainter *p,int x,int y,int x2,int y2,uint32_t c,int w) {
    p->line(p->context,x,y,x2,y2,c,w);
}
void ui_paint_background(UiPainter *p) {
    panel(p,(UiRect){0,0,560,304},18,0x9aace8,0x6178be,0x203577);
    panel(p,(UiRect){3,3,554,298},16,0xd3ddff,0x8499dc,0xe9efff);
    panel(p,(UiRect){7,7,546,290},12,0xb4c3f1,0x8a9ddd,0x566bac);
    panel(p,(UiRect){7,7,546,50},12,0x6381cc,0x3b519b,0x718cdc);
    line(p,22,9,536,9,0xa9c0ff,1);
    panel(p,(UiRect){18,68,524,112},12,0xf1f5ff,0xd4dff9,0x5d73b4);
    line(p,31,70,530,70,0xffffff,1);
    line(p,26,263,534,263,0x6d82c4,1);
    line(p,26,264,534,264,0xc8d6ff,1);
    /* Original Sims 2 bitmap, at its native 32-pixel size at 96 DPI. */
    p->image(p->context,(UiRect){19,16,32,32});
}
void ui_paint_control(UiPainter *p,unsigned id,const wchar_t *text,unsigned state) {
    UiRect r=ui_control_rect(id);
    if (id==UI_HEADING) {
        UiRect shadow=r;shadow.y+=1;
        p->text(p->context,shadow,text,UI_TITLE_FONT,0x263b79,UI_LEFT);
        p->text(p->context,r,text,UI_TITLE_FONT,0xffffff,UI_LEFT);
    } else if (id==UI_MESSAGE) {
        p->text(p->context,r,text,UI_BODY_FONT,0x1e3269,UI_CENTER);
    } else if (id==UI_HINT) {
        p->text(p->context,r,text,UI_HINT_FONT,0x3a508e,UI_CENTER);
    } else if (id==UI_CREDIT) {
        p->text(p->context,r,text,UI_CREDIT_FONT,0x273d75,UI_RIGHT);
    } else if (id==UI_CLOSE) {
        uint32_t top=(state&UI_HOVER)?0xb7d3ff:0x9ebaf4;
        panel(p,r,13,top,0x5873be,0x253d83);
        int d=(state&UI_PRESSED)?1:0;
        line(p,r.x+9+d,r.y+9+d,r.x+17+d,r.y+17+d,0xffffff,2);
        line(p,r.x+17+d,r.y+9+d,r.x+9+d,r.y+17+d,0xffffff,2);
        if(state&UI_FOCUS)panel(p,(UiRect){r.x+2,r.y+2,r.w-4,r.h-4},11,
                                UI_NO_COLOR,UI_NO_COLOR,0xd2ff87);
    } else {
        panel(p,(UiRect){r.x,r.y+2,r.w,r.h-1},13,0x5066a6,0x5066a6,0x314780);
        uint32_t top=(state&UI_HOVER)?0xe2ffaf:0xd3e1ff;
        uint32_t bottom=(state&UI_HOVER)?0xa5d967:0x8ba6e7;
        if(state&UI_PRESSED){uint32_t t=top;top=bottom;bottom=t;}
        panel(p,(UiRect){r.x,r.y,r.w,r.h-2},13,top,bottom,0x2f478f);
        panel(p,(UiRect){r.x+2,r.y+2,r.w-4,r.h-6},11,UI_NO_COLOR,UI_NO_COLOR,
              (state&UI_FOCUS)?0xc6ff77:0xf0f5ff);
        int d=(state&UI_PRESSED)?1:0;
        UiRect icon={r.x+12+d,r.y+10+d,26,26};
        if(id==UI_KEEP) {
            panel(p,icon,13,0xd8ff9d,0x81c63c,0x508635);
            line(p,icon.x+7,icon.y+13,icon.x+11,icon.y+17,0x285731,2);
            line(p,icon.x+11,icon.y+17,icon.x+19,icon.y+8,0x285731,2);
        } else {
            panel(p,icon,13,0xc4dfff,0x7098d8,0x3c5e9b);
            line(p,icon.x+6,icon.y+10,icon.x+19,icon.y+10,0x284a83,2);
            line(p,icon.x+19,icon.y+10,icon.x+15,icon.y+6,0x284a83,2);
            line(p,icon.x+19,icon.y+16,icon.x+6,icon.y+16,0x284a83,2);
            line(p,icon.x+6,icon.y+16,icon.x+10,icon.y+20,0x284a83,2);
        }
        UiRect label={r.x+43+d,r.y+2+d,r.w-54,r.h-7};
        p->text(p->context,label,text,UI_BUTTON_FONT,0x203b76,UI_CENTER);
    }
}
