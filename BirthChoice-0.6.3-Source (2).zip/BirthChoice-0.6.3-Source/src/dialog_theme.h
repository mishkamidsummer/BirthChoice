#ifndef BIRTH_DIALOG_THEME_H
#define BIRTH_DIALOG_THEME_H
#include <stdint.h>
#include <wchar.h>

enum { UI_WIDTH=560, UI_HEIGHT=304, UI_KEEP=103, UI_FEMALE=101,
       UI_MALE=102, UI_CLOSE=2, UI_HEADING=200, UI_MESSAGE=201,
       UI_HINT=202, UI_CREDIT=203 };
enum { UI_TITLE_FONT, UI_BODY_FONT, UI_HINT_FONT, UI_BUTTON_FONT,
       UI_CREDIT_FONT, UI_FONT_COUNT };
enum { UI_CENTER, UI_LEFT, UI_RIGHT };
enum { UI_FOCUS=1, UI_HOVER=2, UI_PRESSED=4 };
#define UI_NO_COLOR UINT32_C(0xffffffff)
typedef struct { int x,y,w,h; } UiRect;
typedef struct {
    void *context;
    void (*rounded)(void *,UiRect,int,uint32_t,uint32_t,uint32_t);
    void (*line)(void *,int,int,int,int,uint32_t,int);
    void (*image)(void *,UiRect);
    void (*text)(void *,UiRect,const wchar_t *,unsigned,uint32_t,unsigned);
} UiPainter;

static const int ui_font_sizes[UI_FONT_COUNT]={22,17,13,15,11};
UiRect ui_control_rect(unsigned id);
void ui_paint_background(UiPainter *p);
void ui_paint_control(UiPainter *p,unsigned id,const wchar_t *text,unsigned state);
#endif
